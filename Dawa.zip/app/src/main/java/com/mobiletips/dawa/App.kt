package com.mobiletips.dawa

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object C {
    val brand = Color(0xFF0F9D6E)
    val dark = Color(0xFF0B6E4F)
    val soft = Color(0xFFE6F6EF)
    val bg = Color(0xFFF2F5F4)
    val text = Color(0xFF14231D)
    val sub = Color(0xFF64748B)
    val line = Color(0xFFE2E8F0)
    val amber = Color(0xFFFEF3C7)
    val head = Brush.linearGradient(listOf(Color(0xFF0F9D6E), Color(0xFF0B7A5A)))
}

sealed class Page {
    data class MedPage(val id: Long) : Page()
    data class GenPage(val id: Long) : Page()
}

@Composable
fun App() {
    MaterialTheme(colorScheme = lightColorScheme(primary = C.brand)) {
        val stack = remember { mutableStateListOf<Page>() }
        val open: (Page) -> Unit = { stack.add(it) }
        BackHandler(stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }
        Box(Modifier.fillMaxSize().background(C.bg)) {
            if (!Db.ready.value) Column(Modifier.fillMaxSize().background(C.brand), Arrangement.Center, Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Color.White)
                Spacer(Modifier.height(14.dp))
                Text(L("ওষুধের তালিকা সাজানো হচ্ছে…", "Preparing the medicine list…"), color = Color.White)
            } else when (val p = stack.lastOrNull()) {
                null -> Home(open)
                is Page.MedPage -> MedScreen(p.id, open) { stack.removeAt(stack.lastIndex) }
                is Page.GenPage -> GenScreen(p.id, open) { stack.removeAt(stack.lastIndex) }
            }
        }
    }
}

@Composable
fun Header(title: String, sub: String = "", onBack: (() -> Unit)? = null, right: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(C.head).statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) IconButton(onBack) { Icon(Icons.Filled.ArrowBack, L("পেছনে", "Back"), tint = Color.White) }
        else Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1)
        }
        right()
    }
}

@Composable
fun Chip(t: String, on: Boolean, onClick: () -> Unit) {
    Text(
        t, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
        color = if (on) Color.White else C.text,
        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) C.brand else Color.White)
            .border(1.dp, if (on) C.brand else C.line, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

// ---------------- home ----------------

@Composable
fun Home(open: (Page) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> SearchTab(open)
                1 -> ListTab(L("⭐ পছন্দের ওষুধ", "⭐ Favourites"), Saved.favs.value, L("কোনো ওষুধের পেজে ⭐ চাপলে এখানে থাকবে।", "Tap ⭐ on a medicine to keep it here."), open)
                else -> MoreTab()
            }
        }
        Row(Modifier.fillMaxWidth().background(Color.White).navigationBarsPadding().padding(vertical = 4.dp)) {
            listOf("🔍" to L("খুঁজুন", "Search"), "⭐" to L("পছন্দ", "Favourites"), "☰" to L("আরও", "More")).forEachIndexed { i, (ic, t) ->
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { tab = i }.padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(ic, fontSize = 20.sp)
                    Text(t, fontSize = 12.sp, color = if (tab == i) C.brand else C.sub, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun SearchTab(open: (Page) -> Unit) {
    var by by remember { mutableStateOf("brand") }
    var q by remember { mutableStateOf("") }
    var meds by remember { mutableStateOf<List<Med>>(emptyList()) }
    var gens by remember { mutableStateOf<List<Gen>>(emptyList()) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(q, by) {
        delay(150)
        withContext(Dispatchers.IO) {
            if (by == "use") { gens = Db.byUse(q); meds = emptyList() } else { meds = Db.search(by, q); gens = emptyList() }
        }
    }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) {} }
    Column(Modifier.fillMaxSize()) {
        Header("Dawa", L("${bn(Db.count.substringBefore('/'))}টি ওষুধ · ইন্টারনেট ছাড়াই চলে", "${Db.count.substringBefore('/')} medicines · works offline"))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip(L("ব্র্যান্ড", "Brand"), by == "brand") { by = "brand" }
            Chip(L("জেনেরিক", "Generic"), by == "generic") { by = "generic" }
            Chip(L("রোগ / কাজ", "Use"), by == "use") { by = "use" }
            Chip(L("কোম্পানি", "Company"), by == "company") { by = "company" }
        }
        OutlinedTextField(
            q, { q = it }, singleLine = true, shape = RoundedCornerShape(16.dp),
            placeholder = {
                Text(when (by) {
                    "generic" -> L("জেনেরিক নাম (যেমন: paracetamol)", "Generic name (e.g. paracetamol)")
                    "use" -> L("রোগ ইংরেজিতে (যেমন: fever, pain)", "Use (e.g. fever, pain)")
                    "company" -> L("কোম্পানির নাম (যেমন: square)", "Company (e.g. square)")
                    else -> L("ওষুধের নাম (যেমন: napa)", "Brand name (e.g. napa)")
                })
            },
            leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) },
            trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Filled.Close, L("মুছুন", "Clear")) } },
            colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(12.dp).focusRequester(focus)
        )
        if (q.isBlank()) {
            val recent = remember(Saved.recent.value) { Db.medsOf(Saved.recent.value) }
            if (recent.isEmpty()) Hint()
            else {
                Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(L("সম্প্রতি দেখা", "Recently viewed"), fontWeight = FontWeight.Bold, color = C.sub, modifier = Modifier.weight(1f))
                    TextButton({ Saved.clearRecent() }) { Text(L("মুছুন", "Clear")) }
                }
                MedList(recent, open)
            }
        } else if (by == "use") {
            if (gens.isEmpty()) Empty() else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(gens, key = { it.id }) { g -> GenCard(g) { open(Page.GenPage(g.id)) } }
            }
        } else {
            if (meds.isEmpty()) Empty() else MedList(meds, open)
        }
    }
}

@Composable
private fun Hint() {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("💊", fontSize = 54.sp)
        Text(L("ওষুধের নাম লিখুন", "Type a medicine name"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(L("ব্র্যান্ড, জেনেরিক, রোগ বা কোম্পানির নাম দিয়ে খুঁজতে পারবেন। নাম ইংরেজি অক্ষরে লিখুন।",
            "Search by brand, generic, use or company."), color = C.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun Empty() {
    Text(L("কিছু পাওয়া যায়নি। বানান একটু বদলে দেখুন।", "Nothing found. Try another spelling."), color = C.sub, modifier = Modifier.padding(24.dp))
}

@Composable
fun MedList(list: List<Med>, open: (Page) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list, key = { it.id }) { m -> MedCard(m) { open(Page.MedPage(m.id)) } }
    }
}

fun formIcon(form: String): String {
    val f = form.lowercase()
    return when {
        "syrup" in f || "suspension" in f || "solution" in f || "drop" in f || "elixir" in f -> "🧴"
        "injection" in f || "infusion" in f -> "💉"
        "capsule" in f -> "💊"
        "cream" in f || "ointment" in f || "gel" in f || "lotion" in f -> "🧪"
        "inhaler" in f || "spray" in f -> "🌬"
        else -> "⚪"
    }
}

@Composable
fun MedCard(m: Med, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(C.soft), contentAlignment = Alignment.Center) { Text(formIcon(m.form), fontSize = 22.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.brand, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = C.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                if (m.id in Saved.favs.value) Text(" ⭐", fontSize = 12.sp)
            }
            Text(listOf(m.form, m.strength).filter { it.isNotBlank() }.joinToString(" · "), fontSize = 13.sp, color = C.dark, maxLines = 1)
            Text(m.gname, fontSize = 13.sp, color = C.sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(m.company, fontSize = 12.sp, color = C.sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun GenCard(g: Gen, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).clickable(onClick = onClick).padding(12.dp)) {
        Text(g.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (g.cls.isNotBlank()) Text(g.cls, fontSize = 13.sp, color = C.dark, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (g.ind.isNotBlank()) Text(g.ind, fontSize = 12.sp, color = C.sub, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(bn("${g.count}") + L("টি ব্র্যান্ড", " brands"), fontSize = 12.sp, color = C.brand, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ListTab(title: String, ids: List<Long>, empty: String, open: (Page) -> Unit) {
    val list = remember(ids) { Db.medsOf(ids) }
    Column(Modifier.fillMaxSize()) {
        Header(title)
        Spacer(Modifier.height(10.dp))
        if (list.isEmpty()) Text(empty, color = C.sub, modifier = Modifier.padding(24.dp)) else MedList(list, open)
    }
}

@Composable
fun MoreTab() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Header(L("আরও", "More"))
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card {
                Text(L("ভাষা", "Language"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Chip("বাংলা", Lang.code.value == "bn") { Lang.set(ctx, "bn") }
                    Chip("English", Lang.code.value == "en") { Lang.set(ctx, "en") }
                }
            }
            Card {
                Text(L("ওষুধের তালিকা", "Medicine list"), fontWeight = FontWeight.Bold)
                val (m, g) = (Db.count.split("/") + listOf("", "")).let { it[0] to it[1] }
                Text(L("${bn(m)}টি ব্র্যান্ড, ${bn(g)}টি জেনেরিক — সব ফোনের ভেতরেই আছে, ইন্টারনেট লাগে না।",
                    "$m brands, $g generics — all inside the phone, no internet needed."), color = C.sub, fontSize = 14.sp)
            }
            Disclaimer()
            Text(L("Dawa · সংস্করণ ১.০", "Dawa · version 1.0"), color = C.sub, fontSize = 12.sp)
        }
    }
}

@Composable
fun Card(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).padding(14.dp)) { content() }
}

@Composable
fun Disclaimer() {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.amber).padding(14.dp)) {
        Text(L("⚠ সতর্কতা", "⚠ Please note"), fontWeight = FontWeight.Bold, color = Color(0xFF78350F))
        Text(
            L("এই অ্যাপের তথ্য শুধু জানার জন্য। এটা ডাক্তারের পরামর্শের বিকল্প নয়, কোনো রোগ নির্ণয় বা চিকিৎসা করে না। ওষুধ খাওয়ার আগে ডাক্তার বা ফার্মাসিস্টের পরামর্শ নিন। দাম বদলে থাকতে পারে।",
                "This information is for reference only. It is not medical advice and does not diagnose or treat any condition. Ask a doctor or pharmacist before taking any medicine. Prices may have changed."),
            fontSize = 13.sp, color = Color(0xFF78350F)
        )
    }
}

/** Bangla digits in Bangla mode. */
fun bn(s: String): String = if (Lang.code.value == "en") s else s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")

// ---------------- one medicine ----------------

@Composable
fun MedScreen(id: Long, open: (Page) -> Unit, back: () -> Unit) {
    val m = remember(id) { Db.med(id) }
    if (m == null) { LaunchedEffect(Unit) { back() }; return }
    LaunchedEffect(id) { Saved.opened(id) }
    val g = remember(m.gid) { Db.gen(m.gid) }
    val others = remember(m.gid) { Db.brandsOf(m.gid).filter { it.id != m.id } }
    val fav = id in Saved.favs.value
    Column(Modifier.fillMaxSize()) {
        Header(m.brand, m.company, back) {
            IconButton({ Saved.toggleFav(id) }) {
                Icon(Icons.Filled.Star, if (fav) L("পছন্দ থেকে সরান", "Remove favourite") else L("পছন্দে রাখুন", "Add to favourites"),
                    tint = if (fav) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.6f))
            }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formIcon(m.form), fontSize = 30.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(m.brand, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            Text(listOf(m.form, m.strength).filter { it.isNotBlank() }.joinToString(" · "), color = C.dark, fontSize = 15.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row2(L("জেনেরিক", "Generic"), m.gname, link = g != null) { if (g != null) open(Page.GenPage(g.id)) }
                    Row2(L("কোম্পানি", "Company"), m.company)
                    if (g != null && g.cls.isNotBlank()) Row2(L("শ্রেণি", "Class"), g.cls)
                    if (m.price.isNotBlank()) Row2(L("দাম", "Price"), m.price)
                }
            }
            if (g != null) items(g.info) { (t, body) -> Section(sectionTitle(t), body, t.lowercase().startsWith("indication")) }
            if (g == null || g.info.isEmpty()) item { Card { Text(L("এই ওষুধের বিস্তারিত তথ্য তালিকায় নেই।", "No details for this medicine."), color = C.sub) } }
            if (others.isNotEmpty()) {
                item {
                    Text(L("একই ওষুধ অন্য কোম্পানির (${bn("${others.size}")})", "Same medicine, other brands (${others.size})"),
                        fontWeight = FontWeight.Bold, color = C.dark, modifier = Modifier.padding(top = 6.dp))
                }
                items(others.take(60), key = { it.id }) { o -> MedCard(o) { open(Page.MedPage(o.id)) } }
                if (others.size > 60 && g != null) item { TextButton({ open(Page.GenPage(g.id)) }) { Text(L("সব দেখুন →", "See all →")) } }
            }
            item { Disclaimer() }
        }
    }
}

@Composable
private fun Row2(k: String, v: String, link: Boolean = false, onClick: () -> Unit = {}) {
    if (v.isBlank()) return
    Row(Modifier.fillMaxWidth().clickable(enabled = link, onClick = onClick).padding(vertical = 4.dp)) {
        Text(k, color = C.sub, fontSize = 14.sp, modifier = Modifier.width(84.dp))
        Text(v + if (link) "  ›" else "", fontSize = 14.sp, color = if (link) C.brand else C.text, fontWeight = if (link) FontWeight.Bold else FontWeight.Normal)
    }
}

/** A section like "Side effects": tap to open/close. */
@Composable
fun Section(title: String, body: String, startOpen: Boolean) {
    var openNow by remember { mutableStateOf(startOpen) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { openNow = !openNow }.padding(14.dp).animateContentSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = C.dark, modifier = Modifier.weight(1f))
            Text(if (openNow) "▲" else "▼", color = C.sub)
        }
        if (openNow) Text(body, fontSize = 14.sp, color = C.text, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ---------------- one generic: all its brands ----------------

@Composable
fun GenScreen(id: Long, open: (Page) -> Unit, back: () -> Unit) {
    val g = remember(id) { Db.gen(id) }
    if (g == null) { LaunchedEffect(Unit) { back() }; return }
    val all = remember(id) { Db.brandsOf(id) }
    var form by remember { mutableStateOf("") }
    val forms = remember(all) { all.map { it.form }.filter { it.isNotBlank() }.distinct() }
    Column(Modifier.fillMaxSize()) {
        Header(g.name, bn("${all.size}") + L("টি ব্র্যান্ড", " brands"), back)
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (g.cls.isNotBlank()) item { Card { Row2(L("শ্রেণি", "Class"), g.cls) } }
            items(g.info) { (t, body) -> Section(sectionTitle(t), body, t.lowercase().startsWith("indication")) }
            if (forms.size > 1) item {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip(L("সব", "All"), form.isEmpty()) { form = "" }
                    forms.forEach { f -> Chip(f, form == f) { form = if (form == f) "" else f } }
                }
            }
            items(all.filter { form.isEmpty() || it.form == form }, key = { it.id }) { m -> MedCard(m) { open(Page.MedPage(m.id)) } }
            item { Disclaimer() }
        }
    }
}

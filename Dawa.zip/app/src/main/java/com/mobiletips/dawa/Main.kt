package com.mobiletips.dawa

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

sealed class Page {
    data class Detail(val id: Long) : Page()
    data class Generic(val id: Long) : Page()
    data class Cheaper(val id: Long) : Page()
    data class ClassGens(val cls: String) : Page()
    data class Company(val name: String) : Page()
    data object Classes : Page()
    data object Companies : Page()
    data object Recent : Page()
    data object CheapHelp : Page()
}

object Nav {
    val stack = mutableStateListOf<Page>()
    val tab = mutableStateOf(0)
    val searchMode = mutableStateOf("brand")
    fun open(p: Page) { stack.add(p) }
    fun back() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun toTab(i: Int, mode: String? = null) { stack.clear(); tab.value = i; if (mode != null) searchMode.value = mode }
}

@Composable
fun MainShell() {
    BackHandler(Nav.stack.isNotEmpty() || Nav.tab.value != 0) { if (Nav.stack.isNotEmpty()) Nav.back() else Nav.tab.value = 0 }
    LaunchedEffect(Unit) { Account.startWatch() }
    Column(Modifier.fillMaxSize().background(C.bg)) {
        Box(Modifier.weight(1f)) {
            when (val p = Nav.stack.lastOrNull()) {
                null -> when (Nav.tab.value) {
                    0 -> HomeScreen()
                    1 -> SearchScreen()
                    2 -> MedListScreen(L("পছন্দের ওষুধ", "Favourites"), Saved.favs.value, L("এখনো কিছু নেই। ওষুধের পাশে ♡ চাপলে এখানে জমা থাকবে।", "Nothing yet. Tap ♡ on a medicine to keep it here."), back = false)
                    else -> MeScreen()
                }
                is Page.Detail -> DetailScreen(p.id)
                is Page.Generic -> GenericScreen(p.id)
                is Page.Cheaper -> CheaperScreen(p.id)
                is Page.ClassGens -> ClassGensScreen(p.cls)
                is Page.Company -> CompanyScreen(p.name)
                Page.Classes -> ClassesScreen()
                Page.Companies -> CompaniesScreen()
                Page.Recent -> MedListScreen(L("সম্প্রতি দেখা", "Recently viewed"), Saved.recent.value, L("এখনো কোনো ওষুধ দেখা হয়নি।", "No medicines viewed yet."), back = true)
                Page.CheapHelp -> CheapHelpScreen()
            }
        }
        BottomBar()
    }
}

@Composable
private fun BottomBar() {
    val items = listOf("home" to L("হোম", "Home"), "search" to L("খুঁজুন", "Search"), "heart" to L("পছন্দ", "Saved"), "user" to L("আমি", "Me"))
    Row(
        Modifier.navigationBarsPadding().padding(start = 12.dp, end = 12.dp, bottom = 10.dp, top = 4.dp).fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x22102850), spotColor = Color(0x22102850))
            .clip(RoundedCornerShape(24.dp)).background(Color.White).padding(6.dp)
    ) {
        items.forEachIndexed { i, (ic, label) ->
            val on = Nav.tab.value == i && Nav.stack.isEmpty()
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(if (on) C.brand else Color.Transparent)
                    .clickable { Nav.toTab(i) }.padding(vertical = 7.dp)
                    .semantics { role = Role.Tab; contentDescription = label },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Ico(ic, if (on) Color.White else C.mute, 22.dp)
                Text(label, fontSize = 12.sp, color = if (on) Color.White else C.mute, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}

// ---------------- home ----------------

@Composable
fun HomeScreen() {
    val first = Account.name.value.substringBefore(' ').ifBlank { "" }
    val tiles = listOf(
        Triple("search", L("ওষুধ খুঁজুন", "Search"), { Nav.toTab(1, "brand") }),
        Triple("capsule", L("জেনেরিক", "Generic"), { Nav.toTab(1, "generic") }),
        Triple("dna", L("ওষুধের শ্রেণি", "Drug class"), { Nav.open(Page.Classes) }),
        Triple("steth", L("রোগ অনুযায়ী", "By disease"), { Nav.toTab(1, "use") }),
        Triple("leaf", L("হারবাল", "Herbal"), { Nav.toTab(1, "herbal") }),
        Triple("factory", L("কোম্পানি", "Company"), { Nav.open(Page.Companies) }),
        Triple("tag", L("কম দামি", "Cheaper"), { Nav.open(Page.CheapHelp) }),
        Triple("heart", L("পছন্দের", "Favourites"), { Nav.toTab(2) }),
        Triple("clock", L("সম্প্রতি দেখা", "Recent"), { Nav.open(Page.Recent) }),
    )
    val colors = listOf(PAIRS[0], PAIRS[1], PAIRS[2], PAIRS[3], PAIRS[4], PAIRS[5], PAIRS[6], Color(0xFFFDEFF4) to Color(0xFFE04F5F), PAIRS[7])
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp)).background(C.head)) {
                Header(
                    if (first.isNotEmpty()) L("স্বাগতম, $first", "Welcome, $first") else L("স্বাগতম", "Welcome"),
                    L("আজ কোন ওষুধ খুঁজবেন?", "Which medicine today?"), round = false
                )
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        Modifier.fillMaxWidth().height(54.dp).shadow(10.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Color.White)
                            .clickable { Nav.toTab(1, "brand") }.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Ico("search", C.brand, 20.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(L("ওষুধের নাম লিখুন…", "Type a medicine name…"), color = C.mute, fontSize = 15.5.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Stat(Modifier.weight(1f), bn(String.format("%,d", Db.brands)), L("ব্র্যান্ড", "brands"), Color.White.copy(alpha = 0.12f))
                        Stat(Modifier.weight(1f), bn(String.format("%,d", Db.generics)), L("জেনেরিক", "generics"), Color.White.copy(alpha = 0.12f))
                        Stat(Modifier.weight(1f), bn("100%"), L("অফলাইনে চলে", "works offline"), C.mint.copy(alpha = 0.22f))
                    }
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                tiles.chunked(3).forEachIndexed { r, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEachIndexed { c, (ic, label, go) ->
                            val (bg, fg) = colors[r * 3 + c]
                            Column(
                                Modifier.weight(1f).shadow(6.dp, RoundedCornerShape(22.dp), ambientColor = Color(0x14102850), spotColor = Color(0x14102850))
                                    .clip(RoundedCornerShape(22.dp)).background(Color.White).clickable { go() }
                                    .padding(top = 16.dp, bottom = 12.dp, start = 4.dp, end = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(bg), contentAlignment = Alignment.Center) { Ico(ic, fg, 28.dp) }
                                Spacer(Modifier.height(8.dp))
                                Text(label, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 2, color = C.text)
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth().shadow(10.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(C.orange, C.red))).clickable { Nav.open(Page.CheapHelp) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(L("কম দামের বিকল্প খুঁজুন", "Find a cheaper alternative"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(L("একই ওষুধ, অন্য কোম্পানির — দাম অনুযায়ী সাজানো", "Same medicine, other companies — sorted by price"), color = Color.White.copy(alpha = 0.95f), fontSize = 13.5.sp)
                }
                Ico("arrow", Color.White, 26.dp)
            }
        }
        val recent = Db.medsOf(Saved.recent.value.take(3))
        if (recent.isNotEmpty()) {
            item { Text(L("সম্প্রতি দেখা", "Recently viewed"), fontWeight = FontWeight.Bold, color = C.sub, modifier = Modifier.padding(horizontal = 20.dp)) }
            items(recent, key = { "r" + it.id }) { m -> Box(Modifier.padding(horizontal = 16.dp)) { MedCard(m) { Nav.open(Page.Detail(m.id)) } } }
        }
    }
}

@Composable
private fun Stat(modifier: Modifier, big: String, small: String, bg: Color) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(bg).padding(horizontal = 12.dp, vertical = 10.dp)) {
        Text(big, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(small, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1)
    }
}

// ---------------- search ----------------

@Composable
fun SearchScreen() {
    var mode by Nav.searchMode
    var q by remember { mutableStateOf("") }
    var meds by remember { mutableStateOf<List<Med>>(emptyList()) }
    var gens by remember { mutableStateOf<List<Gen>>(emptyList()) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(q, mode) {
        delay(120)
        withContext(Dispatchers.IO) {
            if (mode == "use") { gens = Db.byUse(q); meds = emptyList() } else { meds = Db.search(mode, q); gens = emptyList() }
        }
    }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) {} }
    val modes = listOf(Triple("brand", "capsule", L("ব্র্যান্ড", "Brand")), Triple("generic", "dna", L("জেনেরিক", "Generic")), Triple("use", "steth", L("রোগ", "Indication")), Triple("herbal", "leaf", L("হারবাল", "Herbal")))
    Column(Modifier.fillMaxSize()) {
        Header(L("ওষুধ খুঁজুন", "Search"), L("নাম লিখলেই সাথে সাথে ফল", "Results as you type"))
        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                modes.forEach { (key, ic, label) ->
                    val on = mode == key
                    Column(
                        Modifier.weight(1f).then(if (on) Modifier.shadow(8.dp, RoundedCornerShape(18.dp), spotColor = C.brand) else Modifier)
                            .clip(RoundedCornerShape(18.dp)).background(if (on) C.brand else Color.White)
                            .border(1.5.dp, if (on) C.brand else C.line, RoundedCornerShape(18.dp))
                            .clickable { mode = key }.padding(vertical = 10.dp)
                            .semantics { role = Role.Tab; contentDescription = label },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Ico(ic, if (on) Color.White else C.sub, 26.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (on) Color.White else C.sub, maxLines = 1)
                    }
                }
            }
            OutlinedTextField(
                q, { q = it }, singleLine = true, shape = RoundedCornerShape(18.dp),
                placeholder = {
                    Text(when (mode) {
                        "generic" -> L("জেনেরিক (যেমন: paracetamol)", "Generic (e.g. paracetamol)")
                        "use" -> L("রোগ ইংরেজিতে (যেমন: fever)", "Use (e.g. fever, ulcer)")
                        "herbal" -> L("হারবাল ওষুধের নাম", "Herbal medicine name")
                        else -> L("ব্র্যান্ডের নাম (যেমন: napa)", "Brand name (e.g. napa)")
                    }, color = Color(0xFF8A94A6))
                },
                leadingIcon = { Ico("search", C.brand, 20.dp) },
                trailingIcon = {
                    if (q.isNotEmpty()) Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF2F4F7)).clickable { q = "" }
                        .semantics { role = Role.Button; contentDescription = L("মুছুন", "Clear") }, contentAlignment = Alignment.Center) { Ico("close", C.sub, 18.dp) }
                },
                colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, unfocusedBorderColor = Color(0xFFC9D7EC), focusedBorderColor = C.brand),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        }
        val count = if (mode == "use") gens.size else meds.size
        if (q.isBlank() && mode != "herbal") {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(L("চেষ্টা করে দেখুন", "Try these"), fontSize = 13.sp, color = C.mute, fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val words = when (mode) { "generic" -> listOf("paracetamol", "omeprazole", "cefixime"); "use" -> listOf("fever", "ulcer", "allergy", "diabetes"); else -> listOf("napa", "seclo", "fexo", "sergel") }
                    words.forEach { w ->
                        Text(w, color = C.brand, fontSize = 14.5.sp, modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White)
                            .border(1.dp, Color(0xFF9DB8E0), RoundedCornerShape(20.dp)).clickable { q = w }.padding(horizontal = 14.dp, vertical = 9.dp))
                    }
                }
            }
        } else if (count == 0) {
            Text(L("কিছু পাওয়া যায়নি। বানান একটু বদলে দেখুন।", "Nothing found. Try another spelling."), color = C.mute, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(30.dp))
        } else {
            Text(bn("$count") + L("টি পাওয়া গেছে", " found"), fontSize = 13.sp, color = C.mute, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 18.dp, top = 12.dp, bottom = 4.dp))
            LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 16.dp, top = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (mode == "use") items(gens, key = { it.id }) { g -> GenCard(g) { Nav.open(Page.Generic(g.id)) } }
                else items(meds, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
            }
        }
    }
}

// ---------------- one medicine ----------------

@Composable
fun DetailScreen(id: Long) {
    val ctx = LocalContext.current
    val m = remember(id) { Db.med(id) }
    if (m == null) { LaunchedEffect(Unit) { Nav.back() }; return }
    LaunchedEffect(id) { Saved.opened(id) }
    val g = remember(m.gid) { Db.gen(m.gid) }
    val variants = remember(id) { Db.variants(m) }
    val same = remember(id) { Db.sameMedicine(m) }
    val cheaper = same.count { it.up > 0 && m.up > 0 && it.up < m.up }
    val fav = Saved.isFav(id)
    val open = remember(id) { mutableStateListOf(0) }
    Column(Modifier.fillMaxSize()) {
        Header(L("ওষুধের বিস্তারিত", "Medicine details"), "${m.brand} ${m.strength}", onBack = { Nav.back() }) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.14f)).clickable { Saved.toggleFav(id) }
                    .semantics { role = Role.Button; contentDescription = if (fav) L("পছন্দ থেকে সরান", "Remove favourite") else L("পছন্দে রাখুন", "Add to favourites") },
                contentAlignment = Alignment.Center
            ) { HeartIcon(fav, if (fav) Color(0xFFFF8FA0) else Color.White) }
        }
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Row(verticalAlignment = Alignment.Top) {
                        FormBadge(m, 64.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(m.brand, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = C.navy, modifier = Modifier.weight(1f, false))
                                Spacer(Modifier.width(6.dp))
                                Text(m.strength, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = C.brand)
                            }
                            Text(formName(m.form), fontSize = 14.sp, color = C.sub)
                            Text(m.gname, fontSize = 16.sp, fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold, color = Color(0xFF344054),
                                modifier = Modifier.clickable(enabled = g != null) { g?.let { Nav.open(Page.Generic(it.id)) } })
                            Text(m.company, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = C.green, modifier = Modifier.clickable { Nav.open(Page.Company(m.company)) })
                        }
                    }
                    if (variants.size > 1) {
                        Spacer(Modifier.height(12.dp))
                        Text(L("আরও পাওয়া যায়", "Also available"), fontSize = 13.sp, color = C.mute, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            variants.forEach { v -> Pill("${v.strength} | ${formName(v.form)}", v.id == m.id) { if (v.id != m.id) { Nav.back(); Nav.open(Page.Detail(v.id)) } } }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFFEAF2FE), Color(0xFFE6FBF5)))).padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(L("প্রতিটার দাম", "Unit price"), fontSize = 12.5.sp, color = C.sub)
                            Text(if (m.up > 0) money(m.up) else L("দাম জানা নেই", "Price not known"), fontSize = if (m.up > 0) 26.sp else 16.sp, fontWeight = FontWeight.ExtraBold, color = C.navy)
                            if (m.pack.isNotBlank()) Text(m.pack, fontSize = 12.5.sp, color = C.sub)
                        }
                        if (cheaper > 0) Text(
                            bn("$cheaper") + L("টি কম দামে\nআছে →", " cheaper\noption →"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                            modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(C.orange).clickable { Nav.open(Page.Cheaper(id)) }.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionBtn(Modifier.weight(1f), L("অন্য ব্র্যান্ড", "Other brands"), C.brand) { Nav.open(Page.Cheaper(id)) }
                        ActionBtn(Modifier.weight(1f), L("শেয়ার", "Share"), Color(0xFF12B76A)) {
                            val text = buildString {
                                append("${m.brand} ${m.strength} (${m.form})\n${m.gname}\n${m.company}")
                                if (m.up > 0) append("\n" + L("দাম: ", "Price: ") + money(m.up))
                                append("\n\n— Dawa")
                            }
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Dawa"))
                        }
                    }
                }
            }
            val info = g?.info ?: emptyList()
            itemsIndexed(info) { i, (t, body) -> Section(i, sectionTitle(t), body, i in open) { if (i in open) open.remove(i) else open.add(i) } }
            if (info.isEmpty()) item { Card { Text(L("এই ওষুধের বিস্তারিত তথ্য তালিকায় নেই।", "No details for this medicine in the list."), color = C.mute) } }
            item { Disclaimer() }
        }
    }
}

@Composable
private fun ActionBtn(modifier: Modifier, t: String, color: Color, onClick: () -> Unit) {
    Box(modifier.height(48.dp).clip(RoundedCornerShape(14.dp)).background(color).clickable(onClick = onClick).semantics { role = Role.Button }, contentAlignment = Alignment.Center) {
        Text(t, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
    }
}

/** Numbered, coloured section that opens and closes. */
@Composable
fun Section(i: Int, title: String, body: String, open: Boolean, toggle: () -> Unit) {
    val (bg, fg) = PAIRS[i % 7]
    val rot by animateFloatAsState(if (open) 180f else 0f, label = "r")
    Column(
        Modifier.fillMaxWidth().shadow(3.dp, RoundedCornerShape(18.dp), ambientColor = Color(0x10102850), spotColor = Color(0x10102850))
            .clip(RoundedCornerShape(18.dp)).background(Color.White).animateContentSize()
    ) {
        Row(Modifier.fillMaxWidth().clickable(onClick = toggle).padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(bg), contentAlignment = Alignment.Center) {
                Text(bn("${i + 1}"), color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text(title, fontSize = 16.5.sp, fontWeight = FontWeight.Bold, color = C.text, modifier = Modifier.weight(1f))
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(0xFFF2F4F7)).rotate(rot), contentAlignment = Alignment.Center) { Ico("down", C.sub, 16.dp) }
        }
        if (open) Text(body, fontSize = 15.sp, lineHeight = 23.sp, color = Color(0xFF344054), modifier = Modifier.padding(start = 62.dp, end = 16.dp, bottom = 16.dp))
    }
}

// ---------------- lists ----------------

@Composable
fun GenericScreen(id: Long) {
    val g = remember(id) { Db.gen(id) }
    if (g == null) { LaunchedEffect(Unit) { Nav.back() }; return }
    val all = remember(id) { Db.brandsOf(id) }
    var form by remember { mutableStateOf("") }
    val forms = remember(all) { all.map { it.form }.filter { it.isNotBlank() }.distinct() }
    val open = remember(id) { mutableStateListOf(0) }
    Column(Modifier.fillMaxSize()) {
        Header(g.name, bn("${all.size}") + L("টি ব্র্যান্ড", " brands"), onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (g.cls.isNotBlank()) item {
                Card(Modifier.clickable { Nav.open(Page.ClassGens(g.cls)) }) {
                    Text(L("শ্রেণি", "Class"), fontSize = 13.sp, color = C.mute)
                    Text(g.cls + "  ›", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = C.brand)
                }
            }
            itemsIndexed(g.info) { i, (t, body) -> Section(i, sectionTitle(t), body, i in open) { if (i in open) open.remove(i) else open.add(i) } }
            if (forms.size > 1) item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(L("সব", "All"), form.isEmpty()) { form = "" }
                    forms.forEach { f -> Pill(formName(f), form == f) { form = if (form == f) "" else f } }
                }
            }
            items(all.filter { form.isEmpty() || it.form == form }, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
            item { Disclaimer() }
        }
    }
}

/** Same medicine from every company, cheapest first. */
@Composable
fun CheaperScreen(id: Long) {
    val m = remember(id) { Db.med(id) }
    if (m == null) { LaunchedEffect(Unit) { Nav.back() }; return }
    val list = remember(id) { Db.sameMedicine(m) }
    Column(Modifier.fillMaxSize()) {
        Header(L("একই ওষুধ, অন্য ব্র্যান্ড", "Same medicine, other brands"), "${m.gname} ${m.strength}", onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Text(
                        L("${m.gname} ${m.strength} (${formName(m.form)}) — ${bn("${list.size}")}টি কোম্পানির, কম দাম থেকে বেশি দামে সাজানো।",
                            "${m.gname} ${m.strength} (${m.form}) from ${list.size} companies, cheapest first."), fontSize = 14.sp, color = C.sub
                    )
                }
            }
            itemsIndexed(list, key = { _, it -> it.id }) { i, b ->
                Row(
                    Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(20.dp), ambientColor = Color(0x14102850), spotColor = Color(0x14102850))
                        .clip(RoundedCornerShape(20.dp)).background(Color.White)
                        .then(if (b.id == m.id) Modifier.border(2.dp, C.brand, RoundedCornerShape(20.dp)) else Modifier)
                        .clickable { Nav.open(Page.Detail(b.id)) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFFEAF2FE)), contentAlignment = Alignment.Center) { Text(bn("${i + 1}"), fontWeight = FontWeight.ExtraBold, color = C.navy) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.brand, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = C.navy)
                        Text(b.company, fontSize = 13.sp, color = C.green, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (i == 0 && list.size > 1 && b.up > 0) Text(L("সবচেয়ে কম দাম", "Cheapest"), color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF12B76A)).padding(horizontal = 8.dp, vertical = 1.dp))
                    }
                    Text(if (b.up > 0) money(b.up) else "—", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = C.text)
                }
            }
        }
    }
}

@Composable
fun CheapHelpScreen() {
    Column(Modifier.fillMaxSize()) {
        Header(L("কম দামের বিকল্প", "Cheaper alternative"), L("যে ওষুধ খাচ্ছেন, তার নাম লিখুন", "Type the medicine you use"), onBack = { Nav.back() })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card {
                Text(L("কীভাবে কাজ করে", "How it works"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    L("১. ওষুধ খুঁজে তার পেজ খুলুন।\n২. \"অন্য ব্র্যান্ড\" চাপুন।\n৩. একই ওষুধ, একই মাত্রা — সব কোম্পানির দাম কম থেকে বেশি সাজানো দেখবেন।",
                        "1. Find your medicine and open it.\n2. Tap \"Other brands\".\n3. You see the same medicine and strength from every company, cheapest first."),
                    fontSize = 15.sp, color = C.sub, lineHeight = 23.sp
                )
            }
            Button({ Nav.toTab(1, "brand") }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(L("ওষুধ খুঁজুন", "Search a medicine"), fontWeight = FontWeight.Bold) }
            Text(L("দাম বদলাতে পারে — কেনার আগে ফার্মেসিতে মিলিয়ে নিন। ব্র্যান্ড বদলানোর আগে ডাক্তারের পরামর্শ নিন।", "Prices may change — check at the pharmacy. Ask your doctor before switching brands."), fontSize = 13.sp, color = C.mute)
        }
    }
}

@Composable
private fun NameCountList(title: String, sub: String, rows: List<Pair<String, Int>>, unit: String, onPick: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val shown = remember(rows, q) { rows.filter { q.isBlank() || it.first.contains(q.trim(), true) } }
    Column(Modifier.fillMaxSize()) {
        Header(title, sub, onBack = { Nav.back() })
        OutlinedTextField(
            q, { q = it }, singleLine = true, shape = RoundedCornerShape(16.dp), placeholder = { Text(L("খুঁজুন…", "Search…")) },
            leadingIcon = { Ico("search", C.brand, 20.dp) },
            colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(14.dp)
        )
        LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(shown, key = { _, it -> it.first }) { i, (name, n) ->
                val (bg, fg) = PAIRS[i % 7]
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { onPick(name) }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(bg), contentAlignment = Alignment.Center) {
                        Text(name.take(1).uppercase(), color = fg, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(name, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(bn("$n") + unit, fontSize = 12.5.sp, color = C.mute)
                    Spacer(Modifier.width(6.dp))
                    Ico("next", Color(0xFF98A2B3), 18.dp)
                }
            }
        }
    }
}

@Composable
fun ClassesScreen() {
    val rows = remember { Db.classes() }
    NameCountList(L("ওষুধের শ্রেণি", "Drug classes"), bn("${rows.size}") + L("টি শ্রেণি", " classes"), rows, L(" জেনেরিক", " generics")) { Nav.open(Page.ClassGens(it)) }
}

@Composable
fun CompaniesScreen() {
    val rows = remember { Db.companies() }
    NameCountList(L("কোম্পানি", "Companies"), bn("${rows.size}") + L("টি কোম্পানি", " companies"), rows, L(" ব্র্যান্ড", " brands")) { Nav.open(Page.Company(it)) }
}

@Composable
fun ClassGensScreen(cls: String) {
    val list = remember(cls) { Db.gensOfClass(cls) }
    Column(Modifier.fillMaxSize()) {
        Header(cls, bn("${list.size}") + L("টি জেনেরিক", " generics"), onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { g -> GenCard(g) { Nav.open(Page.Generic(g.id)) } }
        }
    }
}

@Composable
fun CompanyScreen(name: String) {
    val list = remember(name) { Db.ofCompany(name) }
    Column(Modifier.fillMaxSize()) {
        Header(name, bn("${list.size}") + L("টি ব্র্যান্ড", " brands"), onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
        }
    }
}

@Composable
fun MedListScreen(title: String, ids: List<Long>, empty: String, back: Boolean) {
    val list = remember(ids) { Db.medsOf(ids) }
    Column(Modifier.fillMaxSize()) {
        Header(title, bn("${list.size}") + L("টি", " saved"), onBack = if (back) ({ Nav.back() }) else null)
        if (list.isEmpty()) Text(empty, color = C.mute, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(30.dp))
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
        }
    }
}

// ---------------- me ----------------

@Composable
fun MeScreen() {
    var pinDialog by remember { mutableStateOf(false) }
    var askOut by remember { mutableStateOf(false) }
    var terms by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Header(L("আমার অ্যাকাউন্ট", "My account"), L("সেটিং ও তথ্য", "Settings and info"))
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(56.dp).clip(CircleShape).background(Brush.linearGradient(listOf(C.brand, C.mint))), contentAlignment = Alignment.Center) {
                            Text(Account.name.value.take(1).uppercase(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(Account.name.value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(Account.phone.value + " · " + occName(Account.occ.value), fontSize = 13.5.sp, color = C.sub)
                            if (Account.org.value.isNotBlank()) Text(Account.org.value, fontSize = 13.sp, color = C.mute)
                        }
                    }
                }
            }
            item { MeRow("A", L("ভাষা", "Language"), L("এখন: বাংলা — চাপলে English", "Now: English — tap for বাংলা"), PAIRS[0]) { Lang.toggle() } }
            item { MeRow("#", L("পিন বদলান", "Change PIN"), L("৪ সংখ্যার পিন", "4-digit PIN"), PAIRS[1]) { pinDialog = true } }
            item { MeRow("↻", L("ওষুধের তালিকা", "Medicine list"), L("${bn(String.format("%,d", Db.brands))}টি ব্র্যান্ড — ফোনের ভেতরেই আছে", "${String.format("%,d", Db.brands)} brands — all inside the phone"), PAIRS[3]) { } }
            item { MeRow("!", L("সতর্কতা ও শর্তাবলি", "Disclaimer and terms"), L("অ্যাপের তথ্য কীভাবে ব্যবহার করবেন", "How to use this information"), PAIRS[5]) { terms = true } }
            item { MeRow("⏻", L("লগআউট", "Log out"), L("এই ফোন থেকে বের হন", "Sign out of this phone"), PAIRS[6]) { askOut = true } }
            item { Text("Dawa · v" + BuildConfig.VERSION_NAME + " · Mobile Tips", fontSize = 12.5.sp, color = Color(0xFF98A2B3), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp)) }
        }
    }
    if (pinDialog) PinDialog { pinDialog = false }
    if (terms) AlertDialog(
        onDismissRequest = { terms = false },
        title = { Text(L("সতর্কতা ও শর্তাবলি", "Disclaimer and terms")) },
        text = {
            Text(
                L("• Dawa-র তথ্য শুধু জানার জন্য। এটা ডাক্তারের পরামর্শের বিকল্প নয় এবং কোনো রোগ নির্ণয় বা চিকিৎসা করে না।\n• ওষুধ খাওয়া, বন্ধ করা বা ব্র্যান্ড বদলানোর আগে ডাক্তার বা ফার্মাসিস্টের পরামর্শ নিন।\n• দাম ও তথ্য পুরোনো হতে পারে।\n• আপনার নাম, নাম্বার, পেশা ও প্রতিষ্ঠান শুধু অ্যাকাউন্ট চালানোর জন্য রাখা হয়।",
                    "• Dawa is for reference only. It is not medical advice and does not diagnose or treat any condition.\n• Ask a doctor or pharmacist before taking, stopping or switching any medicine.\n• Prices and details may be out of date.\n• Your name, number, occupation and organisation are kept only to run your account."),
                lineHeight = 21.sp
            )
        },
        confirmButton = { TextButton({ terms = false }) { Text(L("ঠিক আছে", "OK")) } }
    )
    if (askOut) AlertDialog(
        onDismissRequest = { askOut = false },
        title = { Text(L("লগআউট করবেন?", "Log out?")) },
        text = { Text(L("আবার ঢুকতে নাম্বার আর পিন লাগবে।", "You will need your number and PIN to sign in again.")) },
        confirmButton = { TextButton({ askOut = false; Account.logout() }) { Text(L("হ্যাঁ", "Yes"), color = C.red) } },
        dismissButton = { TextButton({ askOut = false }) { Text(L("না", "No")) } }
    )
}

@Composable
private fun MeRow(mark: String, title: String, sub: String, colors: Pair<Color, Color>, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(colors.first), contentAlignment = Alignment.Center) { Text(mark, color = colors.second, fontWeight = FontWeight.ExtraBold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.5.sp, color = C.mute)
        }
        Ico("next", Color(0xFF98A2B3), 18.dp)
    }
}

@Composable
private fun PinDialog(onClose: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(L("পিন বদলান", "Change PIN")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(old, { if (it.length <= 4) old = it.filter { c -> c.isDigit() } }, label = { Text(L("আগের পিন", "Old PIN")) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                OutlinedTextField(new, { if (it.length <= 4) new = it.filter { c -> c.isDigit() } }, label = { Text(L("নতুন পিন", "New PIN")) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                msg?.let { Text(it, color = if (ok) C.green else C.red, fontWeight = FontWeight.SemiBold) }
            }
        },
        confirmButton = {
            if (ok) TextButton(onClose) { Text(L("ঠিক আছে", "OK")) }
            else TextButton({
                busy = true
                Account.changePin(old, new) { e -> busy = false; ok = e == null; msg = e ?: L("পিন বদলানো হয়েছে ✓", "PIN changed ✓") }
            }, enabled = !busy && old.length == 4 && new.length == 4) { Text(L("সেভ", "Save")) }
        },
        dismissButton = { if (!ok) TextButton(onClose) { Text(L("বাতিল", "Cancel")) } }
    )
}

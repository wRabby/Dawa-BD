package com.mobiletips.dawa

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

sealed class Page {
    data class Detail(val id: Long) : Page()
    data class Generic(val id: Long) : Page()
    data class Cheaper(val id: Long) : Page()
    data class ClassGens(val cls: String) : Page()
    data class Company(val name: String) : Page()
    data object Classes : Page()
    data object Companies : Page()
    data object Recent : Page()
    data object CheapHelp : Page()
}

object Nav {
    val stack = mutableStateListOf<Page>()
    val tab = mutableStateOf(0)
    val searchMode = mutableStateOf("brand")
    fun open(p: Page) { stack.add(p) }
    fun back() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun toTab(i: Int, mode: String? = null) { stack.clear(); tab.value = i; if (mode != null) searchMode.value = mode }
}

@Composable
fun GenericScreen(id: Long) {
    val g = remember(id) { Db.gen(id) }
    if (g == null) { LaunchedEffect(Unit) { Nav.back() }; return }
    val all = remember(id) { Db.brandsOf(id) }
    var form by remember { mutableStateOf("") }
    val forms = remember(all) { all.map { it.form }.filter { it.isNotBlank() }.distinct() }
    val open = remember(id) { mutableStateListOf(0) }
    Column(Modifier.fillMaxSize()) {
        Header(g.name, bn("${all.size}") + L("টি ব্র্যান্ড", " brands"), onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (g.cls.isNotBlank()) item {
                Card(Modifier.clickable { Nav.open(Page.ClassGens(g.cls)) }) {
                    Text(L("শ্রেণি", "Class"), fontSize = 13.sp, color = C.mute)
                    Text(g.cls + "  ›", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = C.brand)
                }
            }
            itemsIndexed(g.info) { i, (t, body) -> Section(i, sectionTitle(t), body, i in open) { if (i in open) open.remove(i) else open.add(i) } }
            if (forms.size > 1) item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(L("সব", "All"), form.isEmpty()) { form = "" }
                    forms.forEach { f -> Pill(formName(f), form == f) { form = if (form == f) "" else f } }
                }
            }
            items(all.filter { form.isEmpty() || it.form == form }, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
            item { Disclaimer() }
        }
    }
}

/** Same medicine from every company, cheapest first. */
@Composable
fun CheaperScreen(id: Long) {
    val m = remember(id) { Db.med(id) }
    if (m == null) { LaunchedEffect(Unit) { Nav.back() }; return }
    val list = remember(id) { Db.sameMedicine(m) }
    Column(Modifier.fillMaxSize()) {
        Header(L("একই ওষুধ, অন্য ব্র্যান্ড", "Same medicine, other brands"), "${m.gname} ${m.strength}", onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Text(
                        L("${m.gname} ${m.strength} (${formName(m.form)}) — ${bn("${list.size}")}টি কোম্পানির, কম দাম থেকে বেশি দামে সাজানো।",
                            "${m.gname} ${m.strength} (${m.form}) from ${list.size} companies, cheapest first."), fontSize = 14.sp, color = C.sub
                    )
                }
            }
            itemsIndexed(list, key = { _, it -> it.id }) { i, b ->
                Row(
                    Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(20.dp), ambientColor = Color(0x14102850), spotColor = Color(0x14102850))
                        .clip(RoundedCornerShape(20.dp)).background(Color.White)
                        .then(if (b.id == m.id) Modifier.border(2.dp, C.brand, RoundedCornerShape(20.dp)) else Modifier)
                        .clickable { Nav.open(Page.Detail(b.id)) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFFEAF2FE)), contentAlignment = Alignment.Center) { Text(bn("${i + 1}"), fontWeight = FontWeight.ExtraBold, color = C.navy) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.brand, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = C.navy)
                        Text(b.company, fontSize = 13.sp, color = C.green, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (i == 0 && list.size > 1 && b.up > 0) Text(L("সবচেয়ে কম দাম", "Cheapest"), color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF12B76A)).padding(horizontal = 8.dp, vertical = 1.dp))
                    }
                    Text(if (b.up > 0) money(b.up) else "—", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = C.text)
                }
            }
        }
    }
}

@Composable
fun CheapHelpScreen() {
    Column(Modifier.fillMaxSize()) {
        Header(L("কম দামের বিকল্প", "Cheaper alternative"), L("যে ওষুধ খাচ্ছেন, তার নাম লিখুন", "Type the medicine you use"), onBack = { Nav.back() })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card {
                Text(L("কীভাবে কাজ করে", "How it works"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    L("১. ওষুধ খুঁজে তার পেজ খুলুন।\n২. \"অন্য ব্র্যান্ড\" চাপুন।\n৩. একই ওষুধ, একই মাত্রা — সব কোম্পানির দাম কম থেকে বেশি সাজানো দেখবেন।",
                        "1. Find your medicine and open it.\n2. Tap \"Other brands\".\n3. You see the same medicine and strength from every company, cheapest first."),
                    fontSize = 15.sp, color = C.sub, lineHeight = 23.sp
                )
            }
            Button({ Nav.toTab(1, "brand") }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(L("ওষুধ খুঁজুন", "Search a medicine"), fontWeight = FontWeight.Bold) }
            Text(L("দাম বদলাতে পারে — কেনার আগে ফার্মেসিতে মিলিয়ে নিন। ব্র্যান্ড বদলানোর আগে ডাক্তারের পরামর্শ নিন।", "Prices may change — check at the pharmacy. Ask your doctor before switching brands."), fontSize = 13.sp, color = C.mute)
        }
    }
}

@Composable
private fun NameCountList(title: String, sub: String, rows: List<Pair<String, Int>>, unit: String, onPick: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val shown = remember(rows, q) { rows.filter { q.isBlank() || it.first.contains(q.trim(), true) } }
    Column(Modifier.fillMaxSize()) {
        Header(title, sub, onBack = { Nav.back() })
        OutlinedTextField(
            q, { q = it }, singleLine = true, shape = RoundedCornerShape(16.dp), placeholder = { Text(L("খুঁজুন…", "Search…")) },
            leadingIcon = { Ico("search", C.brand, 20.dp) },
            colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(14.dp)
        )
        LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(shown, key = { _, it -> it.first }) { i, (name, n) ->
                val (bg, fg) = PAIRS[i % 7]
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { onPick(name) }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(bg), contentAlignment = Alignment.Center) {
                        Text(name.take(1).uppercase(), color = fg, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(name, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(bn("$n") + unit, fontSize = 12.5.sp, color = C.mute)
                    Spacer(Modifier.width(6.dp))
                    Ico("next", Color(0xFF98A2B3), 18.dp)
                }
            }
        }
    }
}

@Composable
fun ClassesScreen() {
    val rows = remember { Db.classes() }
    NameCountList(L("ওষুধের শ্রেণি", "Drug classes"), bn("${rows.size}") + L("টি শ্রেণি", " classes"), rows, L(" জেনেরিক", " generics")) { Nav.open(Page.ClassGens(it)) }
}

@Composable
fun CompaniesScreen() {
    val rows = remember { Db.companies() }
    NameCountList(L("কোম্পানি", "Companies"), bn("${rows.size}") + L("টি কোম্পানি", " companies"), rows, L(" ব্র্যান্ড", " brands")) { Nav.open(Page.Company(it)) }
}

@Composable
fun ClassGensScreen(cls: String) {
    val list = remember(cls) { Db.gensOfClass(cls) }
    Column(Modifier.fillMaxSize()) {
        Header(cls, bn("${list.size}") + L("টি জেনেরিক", " generics"), onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { g -> GenCard(g) { Nav.open(Page.Generic(g.id)) } }
        }
    }
}

@Composable
fun CompanyScreen(name: String) {
    val list = remember(name) { Db.ofCompany(name) }
    Column(Modifier.fillMaxSize()) {
        Header(name, bn("${list.size}") + L("টি ব্র্যান্ড", " brands"), onBack = { Nav.back() })
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
        }
    }
}

@Composable
fun MedListScreen(title: String, ids: List<Long>, empty: String, back: Boolean) {
    val list = remember(ids) { Db.medsOf(ids) }
    Column(Modifier.fillMaxSize()) {
        Header(title, bn("${list.size}") + L("টি", " saved"), onBack = if (back) ({ Nav.back() }) else null)
        if (list.isEmpty()) Text(empty, color = C.mute, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(30.dp))
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
        }
    }
}

// ---------------- me ----------------

@Composable
fun MeRow(mark: String, title: String, sub: String, colors: Pair<Color, Color>, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(colors.first), contentAlignment = Alignment.Center) { Text(mark, color = colors.second, fontWeight = FontWeight.ExtraBold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.5.sp, color = C.mute)
        }
        Ico("next", Color(0xFF98A2B3), 18.dp)
    }
}

@Composable
fun PinDialog(onClose: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(L("পিন বদলান", "Change PIN")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(old, { if (it.length <= 4) old = it.filter { c -> c.isDigit() } }, label = { Text(L("আগের পিন", "Old PIN")) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                OutlinedTextField(new, { if (it.length <= 4) new = it.filter { c -> c.isDigit() } }, label = { Text(L("নতুন পিন", "New PIN")) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                msg?.let { Text(it, color = if (ok) C.green else C.red, fontWeight = FontWeight.SemiBold) }
            }
        },
        confirmButton = {
            if (ok) TextButton(onClose) { Text(L("ঠিক আছে", "OK")) }
            else TextButton({
                busy = true
                Account.changePin(old, new) { e -> busy = false; ok = e == null; msg = e ?: L("পিন বদলানো হয়েছে ✓", "PIN changed ✓") }
            }, enabled = !busy && old.length == 4 && new.length == 4) { Text(L("সেভ", "Save")) }
        },
        dismissButton = { if (!ok) TextButton(onClose) { Text(L("বাতিল", "Cancel")) } }
    )
}

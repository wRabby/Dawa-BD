package com.mobiletips.dawa

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.graphics.vector.group
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object C {
    val brand = Color(0xFF1E6FD9)
    val navy = Color(0xFF0E3F86)
    val deep = Color(0xFF08254F)
    val mint = Color(0xFF4FE3C1)
    val bg = Color(0xFFF3F6FB)
    val text = Color(0xFF101828)
    val sub = Color(0xFF475467)
    val mute = Color(0xFF667085)
    val line = Color(0xFFDCE5F2)
    val green = Color(0xFF027A48)
    val red = Color(0xFFF04438)
    val orange = Color(0xFFFF7A45)
    val warnBg = Color(0xFFFFF6E5)
    val warnText = Color(0xFF7A4100)
    val head = Brush.linearGradient(listOf(Color(0xFF1E6FD9), Color(0xFF0E3F86)))
}

/** Soft background + strong colour pairs for tiles, forms and sections. */
val PAIRS = listOf(
    Color(0xFFEAF2FE) to Color(0xFF1E6FD9), Color(0xFFF4EBFF) to Color(0xFF6941C6), Color(0xFFFDEFF4) to Color(0xFFC11574),
    Color(0xFFE6FBF5) to Color(0xFF0E7C66), Color(0xFFE7F8EF) to Color(0xFF027A48), Color(0xFFFFF4E5) to Color(0xFFC4320A),
    Color(0xFFFEF3F2) to Color(0xFFB42318), Color(0xFFF2F4F7) to Color(0xFF475467)
)

// ---------------- icons (line drawings, 24×24) ----------------

private val iconCache = HashMap<String, ImageVector>()

private val ICONS = mapOf(
    "search" to ("M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14z M20 20l-3.5-3.5" to 0f),
    "capsule" to ("M6.5 8h11a4 4 0 0 1 0 8h-11a4 4 0 0 1 0-8z M12 8v8" to -35f),
    "dna" to ("M7 3c0 6 10 6 10 12s-10 6-10 6 M17 3c0 6-10 6-10 12 M8.5 7h7 M8.5 17h7" to 0f),
    "steth" to ("M6 3v6a4 4 0 0 0 8 0V3 M10 13v3a4 4 0 0 0 8 0v-2 M18 10a2 2 0 1 0 0 4a2 2 0 1 0 0-4z" to 0f),
    "leaf" to ("M5 19c0-8 6-14 15-14 0 9-6 15-14 15 M5 19l8-8" to 0f),
    "factory" to ("M3 21V10l6 4v-4l6 4V5h6v16z M7 17h2 M12 17h2 M17 17h1" to 0f),
    "tag" to ("M3 12V4h8l10 10-8 8z M7.5 7a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3z" to 0f),
    "heart" to ("M12 20s-7-4.4-9.2-9A5 5 0 0 1 12 6a5 5 0 0 1 9.2 5c-2.2 4.6-9.2 9-9.2 9z" to 0f),
    "clock" to ("M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z M12 7v5l3 2" to 0f),
    "home" to ("M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z" to 0f),
    "user" to ("M12 4a4 4 0 1 0 0 8a4 4 0 1 0 0-8z M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" to 0f),
    "back" to ("M15 18l-6-6 6-6" to 0f),
    "next" to ("M9 6l6 6-6 6" to 0f),
    "down" to ("M6 9l6 6 6-6" to 0f),
    "close" to ("M6 6l12 12 M18 6L6 18" to 0f),
    "tablet" to ("M9 4.5a5.5 5.5 0 1 0 0 11a5.5 5.5 0 1 0 0-11z M5.2 13.8l7.6-7.6 M16 11.5a4.5 4.5 0 1 0 0 9a4.5 4.5 0 1 0 0-9z M12.8 19.2l6.4-6.4" to 0f),
    "bottle" to ("M9 3h6v3l2 3v10a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V9l2-3z M7 13h10" to 0f),
    "syringe" to ("M18 2l4 4 M17 7l-9 9-4 1 1-4 9-9z M14 4l6 6 M5 19l-3 3" to 0f),
    "tube" to ("M8 3h8l-1 4H9z M9 7h6v11a3 3 0 0 1-6 0z" to 0f),
    "share" to ("M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7 M12 3v12 M7 8l5-5 5 5" to 0f),
    "arrow" to ("M5 12h14 M13 6l6 6-6 6" to 0f),
    "lock" to ("M6 11h12v10H6z M8 11V7a4 4 0 0 1 8 0v4" to 0f),
    "refresh" to ("M20 11a8 8 0 1 0-2.3 5.7 M20 4v7h-7" to 0f),
    "info" to ("M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z M12 11v6 M12 7.5v.5" to 0f),
    "logout" to ("M15 4h4v16h-4 M10 16l-4-4 4-4 M6 12h10" to 0f),
    "check" to ("M5 12l5 5L20 7" to 0f),
)

fun icon(name: String): ImageVector = iconCache.getOrPut(name) {
    val (d, rot) = ICONS[name] ?: ICONS.getValue("info")
    ImageVector.Builder(defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f).apply {
        group(rotate = rot, pivotX = 12f, pivotY = 12f) {
            addPath(
                pathData = addPathNodes(d),
                fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round
            )
        }
    }.build()
}

@Composable
fun Ico(name: String, tint: Color, size: Dp = 24.dp, desc: String? = null) {
    Icon(icon(name), desc, tint = tint, modifier = Modifier.size(size))
}

fun formIcon(m: Med): String {
    val f = m.form.lowercase()
    return when {
        "herb" in m.kind -> "leaf"
        "syrup" in f || "suspension" in f || "solution" in f || "drop" in f || "elixir" in f || "emulsion" in f -> "bottle"
        "injection" in f || "infusion" in f -> "syringe"
        "capsule" in f -> "capsule"
        "cream" in f || "ointment" in f || "gel" in f || "lotion" in f -> "tube"
        else -> "tablet"
    }
}

fun formColors(m: Med): Pair<Color, Color> = when (formIcon(m)) {
    "capsule" -> PAIRS[2]
    "bottle" -> PAIRS[5]
    "syringe" -> PAIRS[1]
    "tube" -> PAIRS[3]
    "leaf" -> PAIRS[4]
    else -> PAIRS[0]
}

// ---------------- shared pieces ----------------

/** The round language ball: shows the letter of the OTHER language; one tap switches. */
@Composable
fun LangBall(light: Boolean = true) {
    val toBn = Lang.code.value != "bn"
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .background(if (light) Color.White.copy(alpha = 0.18f) else C.brand)
            .border(1.5.dp, if (light) Color.White.copy(alpha = 0.55f) else C.brand, CircleShape)
            .clickable { Lang.toggle() }
            .semantics { role = Role.Button; contentDescription = if (toBn) "বাংলায় বদলান" else "Switch to English" },
        contentAlignment = Alignment.Center
    ) {
        Text(if (toBn) "অ" else "A", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Header(title: String, sub: String = "", onBack: (() -> Unit)? = null, round: Boolean = true, right: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth()
            .clip(if (round) RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp) else RoundedCornerShape(0.dp))
            .background(C.head).statusBarsPadding().padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.14f)).clickable(onClick = onBack)
                    .semantics { role = Role.Button; contentDescription = L("পেছনে", "Back") },
                contentAlignment = Alignment.Center
            ) { Ico("back", Color.White, 22.dp) }
            Spacer(Modifier.width(10.dp))
        } else Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            right()
            LangBall()
        }
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(
        modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(20.dp), ambientColor = Color(0x1A102850), spotColor = Color(0x1A102850))
            .clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp)
    ) { content() }
}

@Composable
fun FormBadge(m: Med, size: Dp = 54.dp) {
    val (bg, fg) = formColors(m)
    Box(Modifier.size(size).clip(RoundedCornerShape(size / 3.4f)).background(bg), contentAlignment = Alignment.Center) {
        Ico(formIcon(m), fg, size * 0.56f)
    }
}

/** One medicine in a list: form icon + tag, name + strength, generic, company, price, ♥. */
@Composable
fun MedCard(m: Med, onClick: () -> Unit) {
    val (bg, fg) = formColors(m)
    val fav = Saved.isFav(m.id)
    Box(
        Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(20.dp), ambientColor = Color(0x14102850), spotColor = Color(0x14102850))
            .clip(RoundedCornerShape(20.dp)).background(Color.White)
    ) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 14.dp, top = 14.dp, bottom = 14.dp, end = 52.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(62.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                FormBadge(m)
                Spacer(Modifier.height(6.dp))
                Text(formName(m.form), fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 6.dp, vertical = 1.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(m.brand, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.navy, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                    Spacer(Modifier.width(6.dp))
                    Text(m.strength, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = C.brand, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(m.gname, fontSize = 13.5.sp, color = C.sub, fontStyle = FontStyle.Italic, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(m.company, fontSize = 13.sp, color = C.green, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (m.up > 0) Text(money(m.up) + L(" / প্রতিটা", " / unit"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = C.text)
            }
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(6.dp).size(44.dp).clip(CircleShape).clickable { Saved.toggleFav(m.id) }
                .semantics { role = Role.Button; contentDescription = if (fav) L("পছন্দ থেকে সরান", "Remove favourite") else L("পছন্দে রাখুন", "Add to favourites") },
            contentAlignment = Alignment.Center
        ) { HeartIcon(fav, if (fav) C.red else Color(0xFF98A2B3)) }
    }
}

@Composable
fun HeartIcon(filled: Boolean, color: Color, size: Dp = 22.dp) {
    if (filled) Text("♥", color = color, fontSize = (size.value * 1.05f).sp, fontWeight = FontWeight.Bold)
    else Ico("heart", color, size)
}

/** Generic row (for "by disease" and drug class lists). */
@Composable
fun GenCard(g: Gen, onClick: () -> Unit) {
    Card(Modifier.clickable(onClick = onClick)) {
        Text(g.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = C.navy)
        if (g.cls.isNotBlank()) Text(g.cls, fontSize = 13.sp, color = C.brand, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (g.ind.isNotBlank()) Text(g.ind, fontSize = 13.sp, color = C.sub, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(bn("${g.count}") + L("টি ব্র্যান্ড", " brands"), fontSize = 13.sp, color = C.green, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Disclaimer() {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.warnBg).padding(14.dp)) {
        Text(L("সতর্কতা", "Please note"), fontWeight = FontWeight.Bold, color = C.warnText, fontSize = 14.5.sp)
        Text(
            L("এই তথ্য শুধু জানার জন্য, ডাক্তারের পরামর্শের বিকল্প নয়। কোনো রোগ নির্ণয় বা চিকিৎসা করে না। ওষুধ খাওয়ার আগে ডাক্তার বা ফার্মাসিস্টের পরামর্শ নিন। দাম বদলে থাকতে পারে।",
                "For reference only — not medical advice, and it does not diagnose or treat any condition. Ask a doctor or pharmacist before taking any medicine. Prices may have changed."),
            fontSize = 13.5.sp, color = C.warnText, lineHeight = 20.sp
        )
    }
}

@Composable
fun Pill(t: String, on: Boolean, onClick: () -> Unit) {
    Text(
        t, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
        color = if (on) C.navy else C.sub,
        modifier = Modifier.clip(RoundedCornerShape(22.dp)).background(if (on) Color(0xFFEAF2FE) else Color.White)
            .border(1.5.dp, if (on) C.brand else C.line, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp)
    )
}

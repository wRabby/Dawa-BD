package com.mobiletips.dawa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Lang.init(applicationContext)
        Saved.init(applicationContext)
        Account.init(applicationContext)
        Thread { try { Db.open(applicationContext) } catch (e: Exception) { e.printStackTrace() } }.start()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = C.brand)) {
                var splash by remember { mutableStateOf(true) }
                when {
                    splash -> Splash { splash = false }
                    Account.state.value == "blocked" -> BlockedScreen()
                    Account.state.value == "in" -> MainShell()
                    else -> AuthScreen()
                }
            }
        }
    }
}

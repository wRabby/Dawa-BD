package com.mobiletips.dawa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Lang.init(applicationContext)
        Saved.init(applicationContext)
        Thread { try { Db.open(applicationContext) } catch (e: Exception) { e.printStackTrace() } }.start()
        setContent { App() }
    }
}

package com.mobiletips.dawa

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The Dawa capsule, drawn (used on the splash and sign-in pages). */
@Composable
fun Logo(size: androidx.compose.ui.unit.Dp, angle: Float = -35f) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        rotate(angle) {
            val h = w * 0.36f
            val top = (w - h) / 2f
            val left = w * 0.08f
            val len = w * 0.84f
            drawRoundRect(Color(0xFFE8F0FC), Offset(left, top), Size(len, h), CornerRadius(h / 2, h / 2))
            drawRoundRect(C.mint, Offset(left + len / 2, top), Size(len / 2, h), CornerRadius(h / 2, h / 2))
            drawRect(C.mint, Offset(left + len / 2, top), Size(h / 2, h))
            drawRoundRect(C.brand, Offset(left, top), Size(len, h), CornerRadius(h / 2, h / 2), style = Stroke(w * 0.045f))
            drawLine(C.brand, Offset(left + len / 2, top), Offset(left + len / 2, top + h), w * 0.045f)
        }
    }
}

/** Opening screen: spinning ring, breathing logo, loading bar. */
@Composable
fun Splash(onDone: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "s")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "spin")
    val pulse by inf.animateFloat(1f, 1.08f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val float by inf.animateFloat(-6f, 6f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "float")
    val bar = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(600))
    }
    LaunchedEffect(Unit) {
        bar.animateTo(1f, tween(2300, easing = FastOutSlowInEasing))
        while (!Db.ready.value) kotlinx.coroutines.delay(100)
        onDone()
    }
    Column(
        Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF1E6FD9), Color(0xFF0E3F86), C.deep), radius = 1400f))
            .clickable { if (Db.ready.value) onDone() },
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(160.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(160.dp).rotate(spin)) {
                drawArc(Color.White.copy(alpha = 0.12f), 0f, 360f, false, style = Stroke(6f))
                drawArc(C.mint, 0f, 100f, false, style = Stroke(8f, cap = StrokeCap.Round))
            }
            Box(
                Modifier.size(108.dp).scale(pulse).shadow(18.dp, RoundedCornerShape(34.dp)).clip(RoundedCornerShape(34.dp)).background(Color.White),
                contentAlignment = Alignment.Center
            ) { Box(Modifier.offset(y = float.dp)) { Logo(70.dp) } }
        }
        Spacer(Modifier.height(24.dp))
        Text("Dawa BD", color = Color.White.copy(alpha = fade.value), fontSize = 46.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        Text(L("ওষুধের নাম, কাজ আর দাম — এক জায়গায়", "Medicine names, uses and prices — in one place"), color = Color.White.copy(alpha = 0.9f * fade.value), fontSize = 15.sp)
        Spacer(Modifier.height(28.dp))
        Box(Modifier.width(190.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.18f))) {
            Box(Modifier.fillMaxWidth(bar.value).height(5.dp).clip(RoundedCornerShape(3.dp)).background(C.mint))
        }
        Spacer(Modifier.height(10.dp))
        Text(L("ওষুধের তালিকা সাজানো হচ্ছে…", "Getting the medicine list ready…"), color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
    }
}

val OCCUPATIONS = listOf(
    "Doctor" to "ডাক্তার", "Intern doctor" to "ইন্টার্ন ডাক্তার", "Medical student" to "মেডিকেল ছাত্র",
    "MATS student" to "MATS ছাত্র", "Nurse" to "নার্স", "Nursing student" to "নার্সিং ছাত্র",
    "Pharmacist" to "ফার্মাসিস্ট", "Pharmacy owner" to "ফার্মেসি মালিক", "Pharmaceutical professional" to "ফার্মাসিউটিক্যাল কর্মী",
    "SACMO" to "SACMO", "Other" to "অন্যান্য"
)

fun occName(en: String): String = OCCUPATIONS.firstOrNull { it.first == en }?.let { L(it.second, it.first) } ?: en

@Composable
fun BlockedScreen() {
    Column(
        Modifier.fillMaxSize().background(C.bg).statusBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(90.dp).clip(CircleShape).background(Color(0xFFFEF3F2)), contentAlignment = Alignment.Center) { Ico("lock", C.red, 44.dp) }
        Spacer(Modifier.height(18.dp))
        Text(L("অ্যাকাউন্ট বন্ধ করা আছে", "Your account is blocked"), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = C.text, textAlign = TextAlign.Center)
        Text(L("অ্যাডমিন এই অ্যাকাউন্ট বন্ধ রেখেছেন। দরকার হলে অ্যাডমিনের সাথে যোগাযোগ করুন।", "The admin has blocked this account. Please contact the admin."),
            fontSize = 15.sp, color = C.sub, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(20.dp))
        Button({ Account.logout() }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = C.brand)) { Text(L("অন্য নাম্বারে লগইন", "Sign in with another number")) }
        Spacer(Modifier.height(12.dp))
        LangBall(light = false)
    }
}

package com.mobiletips.dawa

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The Dawa capsule, drawn (used on the splash and sign-in pages). */
@Composable
fun Logo(size: androidx.compose.ui.unit.Dp, angle: Float = -35f) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        rotate(angle) {
            val h = w * 0.36f
            val top = (w - h) / 2f
            val left = w * 0.08f
            val len = w * 0.84f
            drawRoundRect(Color(0xFFE8F0FC), Offset(left, top), Size(len, h), CornerRadius(h / 2, h / 2))
            drawRoundRect(C.mint, Offset(left + len / 2, top), Size(len / 2, h), CornerRadius(h / 2, h / 2))
            drawRect(C.mint, Offset(left + len / 2, top), Size(h / 2, h))
            drawRoundRect(C.brand, Offset(left, top), Size(len, h), CornerRadius(h / 2, h / 2), style = Stroke(w * 0.045f))
            drawLine(C.brand, Offset(left + len / 2, top), Offset(left + len / 2, top + h), w * 0.045f)
        }
    }
}

/** Opening screen: spinning ring, breathing logo, loading bar. */
@Composable
fun Splash(onDone: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "s")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "spin")
    val pulse by inf.animateFloat(1f, 1.08f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val float by inf.animateFloat(-6f, 6f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "float")
    val bar = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(600))
    }
    LaunchedEffect(Unit) {
        bar.animateTo(1f, tween(2300, easing = FastOutSlowInEasing))
        while (!Db.ready.value) kotlinx.coroutines.delay(100)
        onDone()
    }
    Column(
        Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF1E6FD9), Color(0xFF0E3F86), C.deep), radius = 1400f))
            .clickable { if (Db.ready.value) onDone() },
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(160.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(160.dp).rotate(spin)) {
                drawArc(Color.White.copy(alpha = 0.12f), 0f, 360f, false, style = Stroke(6f))
                drawArc(C.mint, 0f, 100f, false, style = Stroke(8f, cap = StrokeCap.Round))
            }
            Box(
                Modifier.size(108.dp).scale(pulse).shadow(18.dp, RoundedCornerShape(34.dp)).clip(RoundedCornerShape(34.dp)).background(Color.White),
                contentAlignment = Alignment.Center
            ) { Box(Modifier.offset(y = float.dp)) { Logo(70.dp) } }
        }
        Spacer(Modifier.height(24.dp))
        Text("Dawa", color = Color.White.copy(alpha = fade.value), fontSize = 46.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        Text(L("ওষুধের নাম, কাজ আর দাম — এক জায়গায়", "Medicine names, uses and prices — in one place"), color = Color.White.copy(alpha = 0.9f * fade.value), fontSize = 15.sp)
        Spacer(Modifier.height(28.dp))
        Box(Modifier.width(190.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.18f))) {
            Box(Modifier.fillMaxWidth(bar.value).height(5.dp).clip(RoundedCornerShape(3.dp)).background(C.mint))
        }
        Spacer(Modifier.height(10.dp))
        Text(L("ওষুধের তালিকা সাজানো হচ্ছে…", "Getting the medicine list ready…"), color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
    }
}

val OCCUPATIONS = listOf(
    "Doctor" to "ডাক্তার", "Intern doctor" to "ইন্টার্ন ডাক্তার", "Medical student" to "মেডিকেল ছাত্র",
    "MATS student" to "MATS ছাত্র", "Nurse" to "নার্স", "Nursing student" to "নার্সিং ছাত্র",
    "Pharmacist" to "ফার্মাসিস্ট", "Pharmacy owner" to "ফার্মেসি মালিক", "Pharmaceutical professional" to "ফার্মাসিউটিক্যাল কর্মী",
    "SACMO" to "SACMO", "Other" to "অন্যান্য"
)

fun occName(en: String): String = OCCUPATIONS.firstOrNull { it.first == en }?.let { L(it.second, it.first) } ?: en

@Composable
private fun Field(v: String, on: (String) -> Unit, label: String, ph: String, kb: KeyboardType = KeyboardType.Text, secret: Boolean = false, max: Int = 80) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF344054))
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            v, { if (it.length <= max) on(it) }, singleLine = true, placeholder = { Text(ph, color = Color(0xFF8A94A6)) },
            keyboardOptions = KeyboardOptions(keyboardType = kb),
            visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color(0xFFF8FAFD), focusedContainerColor = Color.White, unfocusedBorderColor = Color(0xFFD0D9E6), focusedBorderColor = C.brand),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Register (name, number, email, occupation, organisation, PIN) or sign in (number + PIN). */
@Composable
fun AuthScreen() {
    var register by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var occ by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var agree by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var occOpen by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(C.bg).verticalScroll(rememberScrollState()).imePadding()) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp)).background(Brush.linearGradient(listOf(Color(0xFF1E6FD9), Color(0xFF0E3F86)))).statusBarsPadding()) {
            Column(Modifier.padding(start = 22.dp, end = 22.dp, top = 22.dp, bottom = 56.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White), contentAlignment = Alignment.Center) { Logo(32.dp) }
                    Spacer(Modifier.width(10.dp))
                    Text("Dawa", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    LangBall()
                }
                Spacer(Modifier.height(18.dp))
                Text(if (register) L("নতুন অ্যাকাউন্ট", "Create account") else L("আবার স্বাগতম", "Welcome back"), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (register) L("একবার রেজিস্টার করুন, তারপর অফলাইনেও চলবে", "Register once, then it works offline too") else L("নাম্বার আর পিন দিয়ে ঢুকুন", "Sign in with your number and PIN"),
                    color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp
                )
            }
        }
        Column(
            Modifier.padding(horizontal = 16.dp).offset(y = (-30).dp).fillMaxWidth()
                .shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x22102850), spotColor = Color(0x22102850))
                .clip(RoundedCornerShape(24.dp)).background(Color.White).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (register) Field(name, { name = it }, L("আপনার নাম *", "Your name *"), L("যেমন: রাসেল হোসেন", "e.g. Rasel Hussain"))
            Field(phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, L("মোবাইল নাম্বার *", "Mobile number *"), "01XXXXXXXXX", KeyboardType.Phone, max = 14)
            if (register) {
                Field(email, { email = it }, L("ইমেইল", "Email"), "name@gmail.com", KeyboardType.Email)
                Column {
                    Text(L("পেশা *", "Occupation *"), fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF344054))
                    Spacer(Modifier.height(4.dp))
                    Box {
                        Row(
                            Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFF8FAFD))
                                .border(1.dp, Color(0xFFD0D9E6), RoundedCornerShape(14.dp)).clickable { occOpen = true }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (occ.isEmpty()) L("— পেশা বাছুন —", "— Select occupation —") else occName(occ), color = if (occ.isEmpty()) Color(0xFF8A94A6) else C.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Ico("down", C.sub, 20.dp)
                        }
                        DropdownMenu(occOpen, { occOpen = false }) {
                            OCCUPATIONS.forEach { (en, b) -> DropdownMenuItem(text = { Text(L(b, en), fontSize = 16.sp) }, onClick = { occ = en; occOpen = false }) }
                        }
                    }
                }
                Field(org, { org = it }, L("প্রতিষ্ঠান", "Organisation"), L("হাসপাতাল / ফার্মেসি / কলেজ", "Hospital / pharmacy / college"))
            }
            Field(pin, { pin = it.filter { c -> c.isDigit() } }, if (register) L("৪ সংখ্যার পিন বানান *", "Make a 4-digit PIN *") else L("পিন *", "PIN *"), "• • • •", KeyboardType.NumberPassword, secret = true, max = 4)
            if (register) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { agree = !agree }) {
                Checkbox(agree, { agree = it })
                Text(L("আমি শর্তাবলি ও প্রাইভেসি পলিসিতে রাজি। এই অ্যাপের তথ্য ডাক্তারের পরামর্শের বিকল্প নয়।", "I agree to the terms and privacy policy. This app is not a substitute for a doctor's advice."), fontSize = 13.5.sp, color = C.sub)
            }
            err?.let { Text(it, color = C.red, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
            Button(
                {
                    err = null
                    if (register && !agree) { err = L("শর্তাবলিতে টিক দিন", "Please tick the terms box"); return@Button }
                    busy = true
                    val done: (String?) -> Unit = { e -> busy = false; err = e }
                    if (register) Account.register(name, phone, email, occ, org, pin, done) else Account.login(phone, pin, done)
                },
                enabled = !busy, shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = C.brand),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                if (busy) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                else Text(if (register) L("রেজিস্টার করুন", "Register") else L("লগইন করুন", "Sign in"), fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text(if (register) L("আগে রেজিস্টার করেছেন?", "Already registered?") else L("নতুন ইউজার?", "New here?"), color = C.sub, fontSize = 14.5.sp)
                TextButton({ register = !register; err = null }) { Text(if (register) L("লগইন", "Sign in") else L("রেজিস্টার", "Register"), fontWeight = FontWeight.Bold, fontSize = 14.5.sp) }
            }
        }
        Text(
            L("প্রথমবার রেজিস্টার/লগইন করতে ইন্টারনেট লাগে। এরপর অফলাইনেও চলবে।", "The first register / sign-in needs internet. After that it works offline."),
            color = C.mute, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).navigationBarsPadding().padding(bottom = 20.dp)
        )
    }
}

@Composable
fun BlockedScreen() {
    Column(
        Modifier.fillMaxSize().background(C.bg).statusBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(90.dp).clip(CircleShape).background(Color(0xFFFEF3F2)), contentAlignment = Alignment.Center) { Ico("lock", C.red, 44.dp) }
        Spacer(Modifier.height(18.dp))
        Text(L("অ্যাকাউন্ট বন্ধ করা আছে", "Your account is blocked"), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = C.text, textAlign = TextAlign.Center)
        Text(L("অ্যাডমিন এই অ্যাকাউন্ট বন্ধ রেখেছেন। দরকার হলে অ্যাডমিনের সাথে যোগাযোগ করুন।", "The admin has blocked this account. Please contact the admin."),
            fontSize = 15.sp, color = C.sub, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(20.dp))
        Button({ Account.logout() }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = C.brand)) { Text(L("অন্য নাম্বারে লগইন", "Sign in with another number")) }
        Spacer(Modifier.height(12.dp))
        LangBall(light = false)
    }
}

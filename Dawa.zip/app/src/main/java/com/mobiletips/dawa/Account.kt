package com.mobiletips.dawa

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.runtime.mutableStateOf
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.security.MessageDigest

/**
 * Accounts: register with name, number, occupation … and a 4-digit PIN; sign in with number + PIN.
 * No SMS code. Users live in Firestore "dawa_users/{phone}", so the admin panel can see and block them.
 * After signing in once the app works offline; when online it checks the block.
 */
object Account {
    /** "out" = not signed in, "in" = signed in, "blocked" = blocked by the admin */
    val state = mutableStateOf("out")
    val name = mutableStateOf("")
    val phone = mutableStateOf("")
    val occ = mutableStateOf("")
    val org = mutableStateOf("")

    private lateinit var ctx: Context
    private var watch: ListenerRegistration? = null
    private const val COL = "dawa_users"

    private fun prefs() = ctx.getSharedPreferences("acc", Context.MODE_PRIVATE)

    fun init(c: Context) {
        ctx = c
        val p = prefs()
        phone.value = p.getString("phone", "") ?: ""
        name.value = p.getString("name", "") ?: ""
        occ.value = p.getString("occ", "") ?: ""
        org.value = p.getString("org", "") ?: ""
        state.value = when {
            phone.value.isEmpty() -> "out"
            p.getBoolean("blocked", false) -> "blocked"
            else -> "in"
        }
    }

    val ready: Boolean get() = try { FirebaseApp.getApps(ctx).isNotEmpty() } catch (e: Exception) { false }

    fun online(): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (e: Exception) { true }

    /** 01XXXXXXXXX, or "" when it is not a Bangladeshi mobile number. */
    fun cleanPhone(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("880")) d = d.substring(2)
        if (d.length == 10 && d.startsWith("1")) d = "0$d"
        return if (d.length == 11 && d.startsWith("01")) d else ""
    }

    fun pinHash(phone: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest("dawa:$phone:$pin".toByteArray()).joinToString("") { "%02x".format(it) }

    private fun db() = FirebaseFirestore.getInstance()

    /** Firebase needs a (silent, anonymous) sign-in before reading or writing. */
    private fun signIn(done: (String?) -> Unit) {
        val auth = FirebaseAuth.getInstance()
        if (auth.currentUser != null) { done(null); return }
        auth.signInAnonymously()
            .addOnSuccessListener { done(null) }
            .addOnFailureListener { e -> done(L("সার্ভারে ঢোকা গেল না: ", "Could not reach the server: ") + (e.message ?: "")) }
    }

    private fun checks(): String? = when {
        !ready -> L("সার্ভার এখনো সেটআপ হয়নি (google-services.json)।", "The server is not set up yet (google-services.json).")
        !online() -> L("ইন্টারনেট চালু করুন — প্রথমবার রেজিস্টার/লগইন করতে ইন্টারনেট লাগে।", "Turn on the internet — the first register / sign-in needs it.")
        else -> null
    }

    fun register(nm: String, ph: String, email: String, oc: String, og: String, pin: String, done: (String?) -> Unit) {
        val p = cleanPhone(ph)
        when {
            nm.isBlank() -> return done(L("নাম লিখুন", "Please write your name"))
            p.isEmpty() -> return done(L("সঠিক মোবাইল নাম্বার দিন (01XXXXXXXXX)", "Enter a valid mobile number (01XXXXXXXXX)"))
            oc.isBlank() -> return done(L("পেশা বাছুন", "Please choose your occupation"))
            pin.length != 4 || !pin.all { it.isDigit() } -> return done(L("৪ সংখ্যার পিন দিন", "Enter a 4-digit PIN"))
        }
        checks()?.let { return done(it) }
        signIn { err ->
            if (err != null) return@signIn done(err)
            val uid = FirebaseAuth.getInstance().currentUser?.uid ?: ""
            val ref = db().collection(COL).document(p)
            ref.get().addOnSuccessListener { d ->
                if (d.exists()) return@addOnSuccessListener done(L("এই নাম্বারে আগেই অ্যাকাউন্ট আছে — লগইন করুন।", "This number is already registered — please sign in."))
                val now = System.currentTimeMillis()
                val data = mapOf(
                    "name" to nm.trim(), "phone" to p, "email" to email.trim(), "occ" to oc, "org" to og.trim(),
                    "pinHash" to pinHash(p, pin), "uid" to uid, "blocked" to false,
                    "created" to now, "lastSeen" to now, "app" to BuildConfig.VERSION_NAME
                )
                ref.set(data).addOnSuccessListener {
                    saveLocal(nm.trim(), p, oc, og.trim())
                    done(null)
                }.addOnFailureListener { e -> done(L("সেভ করা গেল না: ", "Could not save: ") + (e.message ?: "")) }
            }.addOnFailureListener { e -> done(L("সার্ভারে সমস্যা: ", "Server problem: ") + (e.message ?: "")) }
        }
    }

    fun login(ph: String, pin: String, done: (String?) -> Unit) {
        val p = cleanPhone(ph)
        if (p.isEmpty()) return done(L("সঠিক মোবাইল নাম্বার দিন", "Enter a valid mobile number"))
        if (pin.length != 4) return done(L("৪ সংখ্যার পিন দিন", "Enter your 4-digit PIN"))
        checks()?.let { return done(it) }
        signIn { err ->
            if (err != null) return@signIn done(err)
            val ref = db().collection(COL).document(p)
            ref.get().addOnSuccessListener { d ->
                when {
                    !d.exists() -> done(L("এই নাম্বারে কোনো অ্যাকাউন্ট নেই — আগে রেজিস্টার করুন।", "No account with this number — please register first."))
                    d.getBoolean("blocked") == true -> done(L("এই অ্যাকাউন্ট বন্ধ করা আছে।", "This account has been blocked."))
                    d.getString("pinHash") != pinHash(p, pin) -> done(L("পিন ভুল হয়েছে", "Wrong PIN"))
                    else -> {
                        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: ""
                        ref.update(mapOf("uid" to uid, "lastSeen" to System.currentTimeMillis(), "app" to BuildConfig.VERSION_NAME))
                        saveLocal(d.getString("name") ?: "", p, d.getString("occ") ?: "", d.getString("org") ?: "")
                        done(null)
                    }
                }
            }.addOnFailureListener { e -> done(L("সার্ভারে সমস্যা: ", "Server problem: ") + (e.message ?: "")) }
        }
    }

    fun changePin(old: String, new: String, done: (String?) -> Unit) {
        if (new.length != 4 || !new.all { it.isDigit() }) return done(L("নতুন পিন ৪ সংখ্যার হবে", "The new PIN must be 4 digits"))
        checks()?.let { return done(it) }
        val p = phone.value
        signIn { err ->
            if (err != null) return@signIn done(err)
            val ref = db().collection(COL).document(p)
            ref.get().addOnSuccessListener { d ->
                if (d.getString("pinHash") != pinHash(p, old)) return@addOnSuccessListener done(L("আগের পিন ভুল", "The old PIN is wrong"))
                ref.update(mapOf("pinHash" to pinHash(p, new), "uid" to (FirebaseAuth.getInstance().currentUser?.uid ?: "")))
                    .addOnSuccessListener { done(null) }
                    .addOnFailureListener { e -> done(e.message ?: "Error") }
            }.addOnFailureListener { e -> done(e.message ?: "Error") }
        }
    }

    private fun saveLocal(nm: String, p: String, oc: String, og: String) {
        prefs().edit().putString("name", nm).putString("phone", p).putString("occ", oc).putString("org", og).putBoolean("blocked", false).apply()
        name.value = nm; phone.value = p; occ.value = oc; org.value = og
        state.value = "in"
        startWatch()
    }

    /** When online: note that the user opened the app, and follow the block switch from the admin panel. */
    fun startWatch() {
        if (!ready || phone.value.isEmpty() || watch != null) return
        signIn { err ->
            if (err != null) return@signIn
            val ref = db().collection(COL).document(phone.value)
            ref.update(mapOf("lastSeen" to System.currentTimeMillis(), "uid" to (FirebaseAuth.getInstance().currentUser?.uid ?: ""), "app" to BuildConfig.VERSION_NAME))
            watch = ref.addSnapshotListener { d, _ ->
                if (d == null || d.metadata.isFromCache) return@addSnapshotListener
                when {
                    !d.exists() -> logout()
                    d.getBoolean("blocked") == true -> { prefs().edit().putBoolean("blocked", true).apply(); state.value = "blocked" }
                    else -> {
                        prefs().edit().putBoolean("blocked", false).apply()
                        if (state.value == "blocked") state.value = "in"
                        d.getString("name")?.let { if (it.isNotBlank()) name.value = it }
                    }
                }
            }
        }
    }

    fun logout() {
        watch?.remove(); watch = null
        prefs().edit().clear().apply()
        name.value = ""; phone.value = ""; occ.value = ""; org.value = ""
        state.value = "out"
    }
}

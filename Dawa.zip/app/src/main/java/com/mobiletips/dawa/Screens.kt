package com.mobiletips.dawa

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// Tabs: 0 Home · 1 Search (opened from Home) · 2 Favourite · 3 More · 4 History

@Composable
fun MainShell() {
    BackHandler(Nav.stack.isNotEmpty() || Nav.tab.value != 0) { if (Nav.stack.isNotEmpty()) Nav.back() else Nav.tab.value = 0 }
    LaunchedEffect(Unit) { Account.startWatch() }
    Column(Modifier.fillMaxSize().background(C.bg)) {
        Box(Modifier.weight(1f)) {
            when (val p = Nav.stack.lastOrNull()) {
                null -> when (Nav.tab.value) {
                    0 -> HomeScreen()
                    1 -> SearchScreen()
                    2 -> MedListScreen(L("পছন্দের ওষুধ", "Favourites"), Saved.favs.value, L("এখনো কিছু নেই। ওষুধের পাশে ♡ চাপলে এখানে জমা থাকবে।", "Nothing yet. Tap ♡ on a medicine to keep it here."), back = false)
                    4 -> MedListScreen(L("ইতিহাস", "History"), Saved.recent.value, L("এখনো কোনো ওষুধ দেখা হয়নি।", "No medicines viewed yet."), back = false)
                    else -> MoreScreen()
                }
                is Page.Detail -> DetailScreen(p.id)
                is Page.Generic -> GenericScreen(p.id)
                is Page.Cheaper -> CheaperScreen(p.id)
                is Page.ClassGens -> ClassGensScreen(p.cls)
                is Page.Company -> CompanyScreen(p.name)
                Page.Classes -> ClassesScreen()
                Page.Companies -> CompaniesScreen()
                Page.Recent -> MedListScreen(L("ইতিহাস", "History"), Saved.recent.value, L("এখনো কোনো ওষুধ দেখা হয়নি।", "No medicines viewed yet."), back = true)
                Page.CheapHelp -> CheapHelpScreen()
            }
        }
        BottomBar()
    }
}

@Composable
private fun BottomBar() {
    val items = listOf(Triple(0, "home", L("হোম", "Home")), Triple(2, "heart", L("পছন্দ", "Favourite")), Triple(4, "clock", L("ইতিহাস", "History")), Triple(3, "menu", L("আরও", "More")))
    Row(
        Modifier.fillMaxWidth().shadow(14.dp, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)).background(Color.White).navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        items.forEach { (tab, ic, label) ->
            val on = Nav.stack.isEmpty() && (Nav.tab.value == tab || (tab == 0 && Nav.tab.value == 1))
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable { Nav.toTab(tab) }.padding(vertical = 6.dp)
                    .semantics { role = Role.Tab; contentDescription = label },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(width = 54.dp, height = 30.dp).clip(RoundedCornerShape(15.dp)).background(if (on) Color(0xFFE3EEFD) else Color.Transparent), contentAlignment = Alignment.Center) {
                    Ico(ic, if (on) C.brand else C.mute, 22.dp)
                }
                Text(label, fontSize = 12.sp, color = if (on) C.brand else C.mute, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}

// ---------------- home ----------------

@Composable
fun HomeScreen() {
    val first = Account.name.value.substringBefore(' ').ifBlank { "" }
    val tiles = listOf(
        Triple("search", L("ওষুধ খুঁজুন", "Search"), { Nav.toTab(1, "brand") }),
        Triple("capsule", L("জেনেরিক দিয়ে", "Drug by Generic"), { Nav.toTab(1, "generic") }),
        Triple("dna", L("শ্রেণি দিয়ে", "Drug by Class"), { Nav.open(Page.Classes) }),
        Triple("steth", L("রোগ দিয়ে", "Drug by Indication"), { Nav.toTab(1, "use") }),
        Triple("leaf", L("হারবাল", "Herbal"), { Nav.toTab(1, "herbal") }),
        Triple("factory", L("কোম্পানি", "Company"), { Nav.open(Page.Companies) }),
        Triple("tag", L("কম দামি বিকল্প", "Cheaper option"), { Nav.open(Page.CheapHelp) }),
        Triple("heart", L("পছন্দের", "Favourite"), { Nav.toTab(2) }),
        Triple("clock", L("ইতিহাস", "History"), { Nav.toTab(4) }),
    )
    val colors = listOf(PAIRS[0], PAIRS[1], PAIRS[2], PAIRS[3], PAIRS[4], PAIRS[5], PAIRS[6], Color(0xFFFDEFF4) to Color(0xFFE04F5F), PAIRS[7])
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp)).background(C.head)) {
                Header(
                    if (first.isNotEmpty()) L("স্বাগতম, $first", "Welcome, $first") else L("স্বাগতম", "Welcome"),
                    L("আজ কোন ওষুধ খুঁজবেন?", "Which medicine today?"), round = false
                )
                Row(
                    Modifier.padding(start = 16.dp, end = 16.dp, bottom = 22.dp).fillMaxWidth().height(54.dp).shadow(10.dp, RoundedCornerShape(18.dp))
                        .clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { Nav.toTab(1, "brand") }.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Ico("search", C.brand, 20.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(L("ওষুধের নাম লিখুন…", "Type a medicine name…"), color = C.mute, fontSize = 15.5.sp)
                }
            }
        }
        item { Banners() }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                tiles.chunked(3).forEachIndexed { r, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEachIndexed { c, (ic, label, go) ->
                            val (bg, fg) = colors[r * 3 + c]
                            Column(
                                Modifier.weight(1f).height(124.dp).shadow(6.dp, RoundedCornerShape(22.dp), ambientColor = Color(0x14102850), spotColor = Color(0x14102850))
                                    .clip(RoundedCornerShape(22.dp)).background(Color.White).clickable { go() }
                                    .padding(top = 16.dp, bottom = 10.dp, start = 4.dp, end = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(bg, Color.White))), contentAlignment = Alignment.Center) { Ico(ic, fg, 28.dp) }
                                Spacer(Modifier.height(8.dp))
                                Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 2, color = C.text, lineHeight = 16.sp)
                            }
                        }
                    }
                }
            }
        }
        val recent = Db.medsOf(Saved.recent.value.take(3))
        if (recent.isNotEmpty()) {
            item { Text(L("সম্প্রতি দেখা", "Recently viewed"), fontWeight = FontWeight.Bold, color = C.sub, modifier = Modifier.padding(horizontal = 20.dp)) }
            items(recent, key = { "r" + it.id }) { m -> Box(Modifier.padding(horizontal = 16.dp)) { MedCard(m) { Nav.open(Page.Detail(m.id)) } } }
        }
    }
}

/** Sliding cards at the top of Home (like a banner). */
@Composable
private fun Banners() {
    val slides = listOf(
        Triple(L("${bn(String.format("%,d", Db.brands))}+ ওষুধ, ইন্টারনেট ছাড়াই", "${String.format("%,d", Db.brands)}+ medicines, offline"),
            L("ব্র্যান্ড, জেনেরিক, রোগ বা কোম্পানি দিয়ে খুঁজুন", "Search by brand, generic, disease or company"), listOf(Color(0xFF1E6FD9), Color(0xFF0E3F86))),
        Triple(L("কম দামের বিকল্প", "Cheaper alternatives"),
            L("একই ওষুধ, অন্য কোম্পানি — দাম অনুযায়ী সাজানো", "Same medicine, other companies — sorted by price"), listOf(Color(0xFFFF7A45), Color(0xFFF04438))),
        Triple(L("বাংলা ও English", "Bangla & English"),
            L("উপরের গোল বলে চাপ দিলেই ভাষা বদলায়", "Tap the round ball at the top to switch"), listOf(Color(0xFF12B76A), Color(0xFF0E7C66))),
    )
    val pager = rememberPagerState(pageCount = { slides.size })
    LaunchedEffect(pager) {
        while (true) { delay(4000); pager.animateScrollToPage((pager.currentPage + 1) % slides.size) }
    }
    Column {
        HorizontalPager(pager, contentPadding = PaddingValues(horizontal = 16.dp), pageSpacing = 10.dp) { i ->
            val (t, s, cols) = slides[i]
            Row(
                Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(cols))
                    .clickable { when (i) { 0 -> Nav.toTab(1, "brand"); 1 -> Nav.open(Page.CheapHelp); else -> Lang.toggle() } }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(t, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(s, color = Color.White.copy(alpha = 0.92f), fontSize = 13.5.sp, maxLines = 2)
                }
                Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                    Ico(when (i) { 0 -> "search"; 1 -> "tag"; else -> "check" }, Color.White, 26.dp)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
            repeat(slides.size) { i ->
                Box(Modifier.padding(3.dp).size(width = if (pager.currentPage == i) 18.dp else 7.dp, height = 7.dp).clip(CircleShape)
                    .background(if (pager.currentPage == i) C.brand else Color(0xFFCBD5E1)))
            }
        }
    }
}

// ---------------- search ----------------

/** Magnifying glass with a smile, for an empty search. */
@Composable
private fun EmptyArt(text: String) {
    Column(Modifier.fillMaxWidth().padding(top = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(150.dp)) {
            val w = size.width
            drawLine(Color(0xFFCBD5E1), Offset(0f, w * 0.45f), Offset(w * 0.18f, w * 0.45f), 3f)
            drawLine(Color(0xFFCBD5E1), Offset(w * 0.78f, w * 0.45f), Offset(w, w * 0.45f), 3f)
            drawCircle(Color(0xFFDDEBFB), w * 0.3f, Offset(w * 0.45f, w * 0.42f))
            drawCircle(Color(0xFF7FB5F0), w * 0.3f, Offset(w * 0.45f, w * 0.42f), style = Stroke(w * 0.035f))
            drawCircle(Color(0xFF3B82F6), w * 0.025f, Offset(w * 0.37f, w * 0.38f))
            drawCircle(Color(0xFF3B82F6), w * 0.025f, Offset(w * 0.53f, w * 0.38f))
            drawArc(Color(0xFF3B82F6), 20f, 140f, false, Offset(w * 0.36f, w * 0.38f), androidx.compose.ui.geometry.Size(w * 0.18f, w * 0.14f), style = Stroke(w * 0.022f, cap = StrokeCap.Round))
            drawLine(Color(0xFF94A3B8), Offset(w * 0.66f, w * 0.64f), Offset(w * 0.82f, w * 0.82f), w * 0.07f, cap = StrokeCap.Round)
            drawCircle(Color(0xFF94A3B8), w * 0.025f, Offset(w * 0.86f, w * 0.2f), style = Stroke(2f))
        }
        Text(text, color = C.sub, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun SearchScreen() {
    var mode by Nav.searchMode
    var q by remember { mutableStateOf("") }
    var meds by remember { mutableStateOf<List<Med>>(emptyList()) }
    var gens by remember { mutableStateOf<List<Gen>>(emptyList()) }
    var history by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(q, mode) {
        delay(120)
        withContext(Dispatchers.IO) {
            if (mode == "use") { gens = Db.byUse(q); meds = emptyList() } else { meds = Db.search(mode, q); gens = emptyList() }
        }
        if (q.trim().length >= 2) { delay(1500); Saved.searched(q) }
    }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) {} }
    val modes = listOf(Triple("brand", "capsule", L("ব্র্যান্ড", "Brand")), Triple("generic", "dna", L("জেনেরিক", "Generic")), Triple("use", "steth", L("রোগ", "Indication")), Triple("herbal", "leaf", L("হারবাল", "Herbal")))
    Column(Modifier.fillMaxSize()) {
        Header(L("ওষুধ খুঁজুন", "Search"), onBack = { Nav.toTab(0) })
        Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                modes.forEach { (key, ic, label) ->
                    val on = mode == key
                    Column(
                        Modifier.weight(1f).then(if (on) Modifier.shadow(8.dp, RoundedCornerShape(16.dp), spotColor = C.brand) else Modifier.shadow(2.dp, RoundedCornerShape(16.dp)))
                            .clip(RoundedCornerShape(16.dp)).background(if (on) C.brand else Color.White)
                            .clickable { mode = key }.padding(vertical = 10.dp)
                            .semantics { role = Role.Tab; contentDescription = label },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Ico(ic, if (on) Color.White else Color(0xFF5B8DB8), 28.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color.White else C.sub, maxLines = 1)
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().height(56.dp).shadow(3.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(start = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ico("search", C.sub, 22.dp)
                Box(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    if (q.isEmpty()) Text(when (mode) {
                        "generic" -> L("জেনেরিক নাম দিয়ে খুঁজুন…", "Search by generic…")
                        "use" -> L("রোগ দিয়ে খুঁজুন (fever)…", "Search by indication…")
                        "herbal" -> L("হারবাল ওষুধ খুঁজুন…", "Search herbal…")
                        else -> L("ব্র্যান্ডের নাম দিয়ে খুঁজুন…", "Search by brand…")
                    }, color = Color(0xFF8A94A6), fontSize = 16.sp)
                    androidx.compose.foundation.text.BasicTextField(
                        q, { q = it; history = false }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp, color = C.text),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(C.brand),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus)
                    )
                }
                if (q.isNotEmpty()) Box(Modifier.size(44.dp).clickable { q = "" }.semantics { role = Role.Button; contentDescription = L("মুছুন", "Clear") }, contentAlignment = Alignment.Center) { Ico("close", C.sub, 20.dp) }
                Box(Modifier.width(1.dp).height(30.dp).background(Color(0xFFDCE5F2)))
                Box(
                    Modifier.size(52.dp).clickable { history = !history }.semantics { role = Role.Button; contentDescription = L("আগের খোঁজা", "Search history") },
                    contentAlignment = Alignment.Center
                ) { Ico("clock", if (history) C.brand else C.sub, 24.dp) }
            }
        }
        if (history) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(L("আগে যা খুঁজেছেন", "Searched before"), fontWeight = FontWeight.Bold, color = C.sub, modifier = Modifier.weight(1f))
                    if (Saved.queries.value.isNotEmpty()) TextButton({ Saved.clearQueries() }) { Text(L("মুছুন", "Clear")) }
                }
                if (Saved.queries.value.isEmpty()) Text(L("এখনো কিছু খোঁজা হয়নি।", "Nothing searched yet."), color = C.mute)
                Saved.queries.value.forEach { w ->
                    Row(Modifier.fillMaxWidth().clickable { q = w; history = false }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Ico("clock", C.mute, 18.dp); Spacer(Modifier.width(12.dp)); Text(w, fontSize = 16.sp)
                    }
                    HorizontalDivider(color = Color(0xFFEEF2F7))
                }
            }
        }
        val count = if (mode == "use") gens.size else meds.size
        if (history) {
        } else if (q.isBlank() && mode != "herbal") {
            EmptyArt(when (mode) { "generic" -> L("জেনেরিক নাম দিয়ে খুঁজুন", "Search by generic name"); "use" -> L("রোগের নাম দিয়ে খুঁজুন", "Search by indication"); else -> L("ব্র্যান্ডের নাম দিয়ে খুঁজুন", "Search by brand name") })
        } else if (count == 0) {
            EmptyArt(L("কিছু পাওয়া যায়নি", "No data found"))
        } else {
            LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 16.dp, top = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (mode == "use") items(gens, key = { it.id }) { g -> GenCard(g) { Nav.open(Page.Generic(g.id)) } }
                else items(meds, key = { it.id }) { m -> MedCard(m) { Nav.open(Page.Detail(m.id)) } }
            }
        }
    }
}

// ---------------- brand details ----------------

/** The sections in the order a doctor reads them; English and Bangla names. */
private val ORDER = listOf(
    "indication" to ("Indications" to "কী কাজে লাগে"),
    "dosage" to ("Dose" to "মাত্রা"),
    "administration" to ("Administration" to "কীভাবে সেবন করবেন"),
    "pediatric" to ("Child dose" to "শিশুদের ক্ষেত্রে"),
    "contraindication" to ("Contraindications" to "কারা খাবেন না"),
    "side effect" to ("Side effects" to "পার্শ্বপ্রতিক্রিয়া"),
    "precaution" to ("Precautions & warnings" to "সতর্কতা"),
    "pregnancy" to ("Pregnancy & Lactation" to "গর্ভাবস্থা ও স্তন্যদান"),
    "therapeutic" to ("Therapeutic Class" to "ওষুধের শ্রেণি"),
    "pharmacology" to ("Mode of Action" to "কীভাবে কাজ করে"),
    "interaction" to ("Interaction" to "অন্য ওষুধের সাথে প্রতিক্রিয়া"),
    "overdose" to ("Overdose" to "অতিরিক্ত সেবন করলে"),
    "duration" to ("Duration of treatment" to "কতদিন খাবেন"),
    "reconstitution" to ("Reconstitution" to "তৈরির নিয়ম"),
    "storage" to ("Storage" to "সংরক্ষণ"),
)

private fun sectionsOf(g: Gen?, m: Med, bangla: Boolean): List<Pair<String, String>> {
    val info = g?.info ?: emptyList()
    val out = ArrayList<Pair<String, String>>()
    val used = HashSet<Int>()
    ORDER.forEach { (key, names) ->
        info.forEachIndexed { i, (t, body) ->
            if (i !in used && key in t.lowercase()) { used += i; out += (if (bangla) names.second else names.first) to body }
        }
    }
    info.forEachIndexed { i, (t, body) -> if (i !in used) out += sectionTitle(t) to body }
    // "Therapeutic Class" from the class name when the text has none
    if (out.none { it.first == "Therapeutic Class" || it.first == "ওষুধের শ্রেণি" } && g != null && g.cls.isNotBlank())
        out.add(minOf(out.size, 8), (if (bangla) "ওষুধের শ্রেণি" else "Therapeutic Class") to g.cls)
    val pack = m.pack.ifBlank { m.price }
    if (pack.isNotBlank()) out += (if (bangla) "প্যাকেট ও দাম" else "Pack size & Price") to pack.replace(" · ", "\n")
    return out
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailScreen(id: Long) {
    val ctx = LocalContext.current
    val m = remember(id) { Db.med(id) }
    if (m == null) { LaunchedEffect(Unit) { Nav.back() }; return }
    LaunchedEffect(id) { Saved.opened(id) }
    val g = remember(m.gid) { Db.gen(m.gid) }
    val variants = remember(id) { Db.variants(m) }
    val same = remember(id) { Db.sameMedicine(m) }
    val cheaper = same.count { it.up > 0 && m.up > 0 && it.up < m.up }
    val fav = Saved.isFav(id)
    var bangla by remember(id) { mutableStateOf(Lang.code.value == "bn") }
    val sections = remember(id, bangla) { sectionsOf(g, m, bangla) }
    val open = remember(id) { mutableStateListOf<Int>() }
    val (fbg, ffg) = formColors(m)
    Column(Modifier.fillMaxSize().background(Color(0xFFEAF2F8))) {
        Header(L("ওষুধের বিস্তারিত", "Brand Details"), onBack = { Nav.back() }) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).clickable { Saved.toggleFav(id) }
                    .semantics { role = Role.Button; contentDescription = if (fav) L("পছন্দ থেকে সরান", "Remove favourite") else L("পছন্দে রাখুন", "Add to favourites") },
                contentAlignment = Alignment.Center
            ) { HeartIcon(fav, if (fav) Color(0xFFFF8FA0) else Color(0xFFFCD34D), 24.dp) }
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).clickable { Nav.toTab(0) }
                    .semantics { role = Role.Button; contentDescription = L("হোম", "Home") },
                contentAlignment = Alignment.Center
            ) { Ico("home", Color.White, 24.dp) }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
            item {
                Column(
                    Modifier.padding(14.dp).fillMaxWidth().shadow(8.dp, RoundedCornerShape(20.dp), ambientColor = Color(0x1A102850), spotColor = Color(0x1A102850))
                        .clip(RoundedCornerShape(20.dp)).background(Color.White).padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(m.brand, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = C.navy, modifier = Modifier.weight(1f, false))
                        Spacer(Modifier.width(6.dp))
                        Text(m.strength, fontSize = 14.sp, color = C.brand, modifier = Modifier.padding(bottom = 4.dp).weight(1f, false), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.width(6.dp))
                        Box(Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(fbg), contentAlignment = Alignment.Center) { Ico(formIcon(m), ffg, 20.dp) }
                    }
                    Text(formName(m.form), fontSize = 15.sp, color = C.sub)
                    Text(m.gname, fontSize = 17.sp, fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold, color = Color(0xFF344054),
                        modifier = Modifier.padding(top = 4.dp).clickable(enabled = g != null) { g?.let { Nav.open(Page.Generic(it.id)) } })
                    Text(m.company, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = C.brand,
                        modifier = Modifier.padding(top = 2.dp).clickable { Nav.open(Page.Company(m.company)) })
                    if (variants.size > 1) {
                        Text(L("আরও পাওয়া যায়:", "Also Available:"), fontSize = 14.sp, color = C.mute, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            variants.forEach { v ->
                                val on = v.id == m.id
                                Row(
                                    Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Color(0xFFDCE8F7) else Color(0xFFF0F2F5))
                                        .then(if (on) Modifier.border(1.5.dp, C.brand, RoundedCornerShape(20.dp)) else Modifier)
                                        .clickable(enabled = !on) { Nav.back(); Nav.open(Page.Detail(v.id)) }.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (on) { Box(Modifier.size(18.dp).clip(CircleShape).background(C.brand), contentAlignment = Alignment.Center) { Ico("check", Color.White, 12.dp) }; Spacer(Modifier.width(6.dp)) }
                                    Text("${v.strength} | ${formName(v.form)}", fontSize = 13.5.sp, color = C.text)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(L("প্রতিটার দাম:", "Unit Price:"), fontSize = 13.sp, color = C.mute)
                            Text(if (m.up > 0) String.format(java.util.Locale.US, "%.2f", m.up).let { bn(it) } + " BDT" else "—", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = C.text)
                        }
                        if (cheaper > 0) Text(
                            bn("$cheaper") + L("টি কম দামে →", " cheaper →"), color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(C.orange).clickable { Nav.open(Page.Cheaper(id)) }.padding(horizontal = 10.dp, vertical = 7.dp)
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DBtn(Modifier.weight(1f), if (bangla) "English" else "বাংলা", Color(0xFFF2F4F7), C.navy) { bangla = !bangla }
                        DBtn(Modifier.weight(1.3f), L("অন্য ব্র্যান্ড", "Other Brand"), Color(0xFF4FA3B5), Color.White) { Nav.open(Page.Cheaper(id)) }
                        DBtn(Modifier.weight(1f), L("শেয়ার", "Share"), C.navy, Color.White) {
                            val text = buildString {
                                append("${m.brand} ${m.strength} (${m.form})\n${m.gname}\n${m.company}")
                                if (m.up > 0) append("\nUnit price: " + String.format(java.util.Locale.US, "%.2f", m.up) + " BDT")
                                append("\n\n— Dawa BD")
                            }
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Dawa BD"))
                        }
                    }
                }
            }
            itemsIndexed(sections) { i, (t, body) -> Section(i, t, body, i in open) { if (i in open) open.remove(i) else open.add(i) } }
            if (sections.isEmpty()) item { Text(L("এই ওষুধের বিস্তারিত তথ্য তালিকায় নেই।", "No details for this medicine in the list."), color = C.mute, modifier = Modifier.padding(20.dp)) }
            item { Box(Modifier.padding(14.dp)) { Disclaimer() } }
        }
    }
}

@Composable
private fun DBtn(modifier: Modifier, t: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        modifier.height(48.dp).shadow(2.dp, RoundedCornerShape(10.dp)).clip(RoundedCornerShape(10.dp)).background(bg).clickable(onClick = onClick).semantics { role = Role.Button },
        contentAlignment = Alignment.Center
    ) { Text(t, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, maxLines = 1) }
}

/** One row of the details list: ⌄ title; tap to open. */
@Composable
fun Section(i: Int, title: String, body: String, open: Boolean, toggle: () -> Unit) {
    val rot by animateFloatAsState(if (open) 180f else 0f, label = "r")
    Column(Modifier.fillMaxWidth().background(if (open) Color.White else Color.Transparent).animateContentSize()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = toggle).padding(horizontal = 16.dp, vertical = 15.dp)
                .semantics { role = Role.Button; contentDescription = title },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.rotate(rot)) { Ico("down", if (open) C.brand else Color(0xFF64748B), 22.dp) }
            Spacer(Modifier.width(14.dp))
            Text(title, fontSize = 18.sp, fontWeight = if (open) FontWeight.Bold else FontWeight.Normal, color = if (open) C.navy else C.text, modifier = Modifier.weight(1f))
        }
        if (open) Text(body, fontSize = 15.5.sp, lineHeight = 24.sp, color = Color(0xFF344054), modifier = Modifier.padding(start = 52.dp, end = 18.dp, bottom = 16.dp))
        HorizontalDivider(color = Color(0xFFD5E0EA))
    }
}

// ---------------- more ----------------

@Composable
fun MoreScreen() {
    val ctx = LocalContext.current
    var pinDialog by remember { mutableStateOf(false) }
    var askOut by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<Pair<String, String>?>(null) }
    val pkg = ctx.packageName
    fun open(u: String) = try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Exception) {}
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp)).background(C.head)) {
            Header(L("আরও", "More"), round = false)
            Row(Modifier.padding(start = 18.dp, end = 18.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                    Text(Account.name.value.take(1).uppercase(), color = C.brand, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(Account.name.value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(Account.phone.value + " · " + occName(Account.occ.value), color = Color.White.copy(alpha = 0.85f), fontSize = 13.5.sp)
                    if (Account.org.value.isNotBlank()) Text(Account.org.value, color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                }
            }
        }
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Group(L("প্রোফাইল", "Profile")) }
            item { MeRow("A", L("ভাষা", "Language"), L("এখন বাংলা — চাপলে English", "Now English — tap for বাংলা"), PAIRS[0]) { Lang.toggle() } }
            item { MeRow("#", L("পিন বদলান", "Change PIN"), L("৪ সংখ্যার পিন", "4-digit PIN"), PAIRS[1]) { pinDialog = true } }
            item { MeRow("◷", L("ইতিহাস", "History"), L("যে ওষুধগুলো দেখেছেন", "Medicines you opened"), PAIRS[7]) { Nav.toTab(4) } }
            item { Group(L("সোশ্যাল", "Social")) }
            item {
                MeRow("↗", L("শেয়ার করুন", "Share"), L("বন্ধুদের Dawa BD পাঠান", "Send Dawa BD to friends"), PAIRS[3]) {
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "Dawa BD — ওষুধের নাম, কাজ আর দাম, ইন্টারনেট ছাড়াই:\nhttps://play.google.com/store/apps/details?id=$pkg")
                    }, "Dawa BD"))
                }
            }
            item { MeRow("✉", L("মতামত দিন", "Feedback"), L("সমস্যা বা পরামর্শ জানান", "Tell us a problem or an idea"), PAIRS[4]) { open("mailto:mdrasel666699990@gmail.com?subject=Dawa%20BD%20feedback") } }
            item { MeRow("★", L("রেটিং দিন", "Rate us"), L("Play Store-এ ৫ তারা দিন", "Rate on Play Store"), PAIRS[5]) { open("market://details?id=$pkg") } }
            item { Group(L("তথ্য", "Info")) }
            item {
                MeRow("i", L("অ্যাপ সম্পর্কে", "About"), "Dawa BD · v" + BuildConfig.VERSION_NAME, PAIRS[0]) {
                    info = L("Dawa BD সম্পর্কে", "About Dawa BD") to L(
                        "Dawa BD-তে ${bn(String.format("%,d", Db.brands))}টি ব্র্যান্ড আর ${bn(String.format("%,d", Db.generics))}টি জেনেরিক ওষুধের নাম, কাজ, মাত্রা ও দাম আছে — ইন্টারনেট ছাড়াই।\n\nতৈরি করেছে Mobile Tips।",
                        "Dawa BD has ${String.format("%,d", Db.brands)} brands and ${String.format("%,d", Db.generics)} generics — names, uses, doses and prices — all offline.\n\nMade by Mobile Tips."
                    )
                }
            }
            item {
                MeRow("!", L("প্রাইভেসি পলিসি ও শর্তাবলি", "Privacy policy and terms"), L("অ্যাপের তথ্য কীভাবে ব্যবহার করবেন", "How to use this information"), PAIRS[6]) {
                    info = L("প্রাইভেসি পলিসি ও শর্তাবলি", "Privacy policy and terms") to L(
                        "• Dawa BD-র তথ্য শুধু জানার জন্য। এটা ডাক্তারের পরামর্শের বিকল্প নয় এবং কোনো রোগ নির্ণয় বা চিকিৎসা করে না।\n• ওষুধ খাওয়া, বন্ধ করা বা ব্র্যান্ড বদলানোর আগে ডাক্তার বা ফার্মাসিস্টের পরামর্শ নিন।\n• দাম ও তথ্য পুরোনো হতে পারে।\n• আপনার নাম, নাম্বার, ইমেইল, পেশা ও প্রতিষ্ঠান শুধু অ্যাকাউন্ট চালানোর জন্য রাখা হয়, কারো কাছে বিক্রি বা শেয়ার করা হয় না।",
                        "• Dawa BD is for reference only. It is not medical advice and does not diagnose or treat any condition.\n• Ask a doctor or pharmacist before taking, stopping or switching any medicine.\n• Prices and details may be out of date.\n• Your name, number, email, occupation and organisation are kept only to run your account and are never sold or shared."
                    )
                }
            }
            item { MeRow("⏻", L("লগআউট", "Log out"), L("এই ফোন থেকে বের হন", "Sign out of this phone"), PAIRS[6]) { askOut = true } }
            item { Text("Dawa BD · v" + BuildConfig.VERSION_NAME + " · Mobile Tips", fontSize = 12.5.sp, color = Color(0xFF98A2B3), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp)) }
        }
    }
    if (pinDialog) PinDialog { pinDialog = false }
    info?.let { (t, body) ->
        AlertDialog(
            onDismissRequest = { info = null },
            title = { Text(t) },
            text = { Text(body, lineHeight = 21.sp) },
            confirmButton = { TextButton({ info = null }) { Text(L("ঠিক আছে", "OK")) } }
        )
    }
    if (askOut) AlertDialog(
        onDismissRequest = { askOut = false },
        title = { Text(L("লগআউট করবেন?", "Log out?")) },
        text = { Text(L("আবার ঢুকতে নাম্বার আর পিন, অথবা Google লাগবে।", "You will need your number and PIN, or Google, to sign in again.")) },
        confirmButton = { TextButton({ askOut = false; Account.logout() }) { Text(L("হ্যাঁ", "Yes"), color = C.red) } },
        dismissButton = { TextButton({ askOut = false }) { Text(L("না", "No")) } }
    )
}

@Composable
private fun Group(t: String) {
    Text(t, fontSize = 13.sp, color = C.mute, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, top = 8.dp))
}

package com.mobiletips.dawa

import android.app.Activity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** The four-colour Google "G". */
@Composable
fun GoogleG(size: Dp = 22.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val sw = w * 0.2f
        val inset = sw / 2
        val box = Size(w - sw, w - sw)
        val tl = Offset(inset, inset)
        drawArc(Color(0xFFEA4335), -150f, 105f, false, tl, box, style = Stroke(sw))
        drawArc(Color(0xFFFBBC05), 150f, 60f, false, tl, box, style = Stroke(sw))
        drawArc(Color(0xFF34A853), 45f, 105f, false, tl, box, style = Stroke(sw))
        drawArc(Color(0xFF4285F4), -10f, 55f, false, tl, box, style = Stroke(sw))
        drawRect(Color(0xFF4285F4), Offset(w / 2, w / 2 - sw / 2), Size(w / 2 - inset / 2, sw))
    }
}

/** Grey box with an icon on the left, like a classic sign-up form. */
@Composable
private fun IconField(
    icon: String, value: String, onChange: (String) -> Unit, hint: String,
    kb: KeyboardType = KeyboardType.Text, secret: Boolean = false, max: Int = 80, enabled: Boolean = true,
    trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(14.dp))
            .background(if (enabled) Color(0xFFEFF3F9) else Color(0xFFE6F6EF))
            .border(1.dp, Color(0xFFDCE5F2), RoundedCornerShape(14.dp)).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ico(icon, C.brand, 24.dp)
        Spacer(Modifier.width(14.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, color = Color(0xFF8A94A6), fontSize = 16.sp)
            BasicTextField(
                value, { if (it.length <= max) onChange(it) }, singleLine = true, enabled = enabled,
                textStyle = TextStyle(fontSize = 16.sp, color = C.text),
                keyboardOptions = KeyboardOptions(keyboardType = kb),
                visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
                cursorBrush = SolidColor(C.brand),
                modifier = Modifier.fillMaxWidth().semantics { contentDescription = hint }
            )
        }
        trailing?.invoke()
    }
}

/** Sign-up / sign-in: Google in one tap, or number + PIN. */
@Composable
fun AuthScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var register by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var occ by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var agree by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var gBusy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var occOpen by remember { mutableStateOf(false) }
    var terms by remember { mutableStateOf(false) }
    val gEmail = Account.gEmail.value
    val viaGoogle = gEmail.isNotEmpty()

    fun google() {
        err = null; gBusy = true
        scope.launch {
            val r = Account.google(ctx as Activity)
            gBusy = false
            when (r) {
                null -> {}
                "new" -> {
                    register = true
                    if (name.isBlank()) name = Account.gName.value
                    email = Account.gEmail.value
                    err = L("Google অ্যাকাউন্ট পাওয়া গেছে ✓ এখন নাম্বার, পেশা আর পিন দিয়ে রেজিস্টার করুন।", "Google account found ✓ Now add your number, occupation and PIN, then register.")
                }
                else -> err = r
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFFF8FAFD)).verticalScroll(rememberScrollState()).imePadding().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEAF2FE)), contentAlignment = Alignment.Center) { Logo(28.dp) }
            Spacer(Modifier.width(8.dp))
            Text("Dawa BD", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = C.navy, modifier = Modifier.weight(1f))
            LangBall(light = false)
        }
        Column(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(L("স্বাগতম", "Welcome"), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = C.text)
            Text(
                if (register) L("চালিয়ে যেতে রেজিস্টার করুন", "Please register to continue") else L("চালিয়ে যেতে লগইন করুন", "Please sign in to continue"),
                fontSize = 18.sp, color = Color(0xFF344054)
            )
        }
        Column(Modifier.padding(horizontal = 22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Google
            if (!viaGoogle) {
                Row(
                    Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(14.dp)).background(Color.White)
                        .border(1.5.dp, Color(0xFFD0D9E6), RoundedCornerShape(14.dp)).clickable(enabled = !gBusy) { google() }
                        .semantics { role = Role.Button },
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    if (gBusy) CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(22.dp)) else GoogleG(22.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(if (register) L("Google দিয়ে রেজিস্টার", "Continue with Google") else L("Google দিয়ে লগইন", "Sign in with Google"),
                        fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = C.text)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HorizontalDivider(Modifier.weight(1f), color = Color(0xFFDCE5F2))
                    Text(L("  অথবা  ", "  or  "), color = C.mute, fontSize = 13.sp)
                    HorizontalDivider(Modifier.weight(1f), color = Color(0xFFDCE5F2))
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFFE6F6EF)).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GoogleG(20.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(L("Google অ্যাকাউন্ট", "Google account"), fontSize = 12.sp, color = C.green, fontWeight = FontWeight.SemiBold)
                        Text(gEmail, fontSize = 14.5.sp, color = C.text)
                    }
                    TextButton({ Account.dropGoogle(); email = "" }) { Text(L("বদলান", "Change"), fontSize = 13.sp) }
                }
            }

            if (register) IconField("user", name, { name = it }, L("আপনার নাম *", "Name *"))
            if (register) IconField("mail", if (viaGoogle) gEmail else email, { email = it }, L("ইমেইল", "Email"), KeyboardType.Email, enabled = !viaGoogle)
            if (register || !viaGoogle) IconField("phone", phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, L("মোবাইল নাম্বার *", "Phone number *"), KeyboardType.Phone, max = 14)
            if (register) Box {
                Row(
                    Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFEFF3F9))
                        .border(1.dp, Color(0xFFDCE5F2), RoundedCornerShape(14.dp)).clickable { occOpen = true }.padding(horizontal = 16.dp)
                        .semantics { role = Role.Button },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Ico("bag", C.brand, 24.dp)
                    Spacer(Modifier.width(14.dp))
                    Text(if (occ.isEmpty()) L("— পেশা বাছুন — *", "— Select occupation — *") else occName(occ),
                        color = if (occ.isEmpty()) Color(0xFF8A94A6) else C.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Ico("down", C.sub, 20.dp)
                }
                DropdownMenu(occOpen, { occOpen = false }) {
                    OCCUPATIONS.forEach { (en, b) -> DropdownMenuItem(text = { Text(L(b, en), fontSize = 16.sp) }, onClick = { occ = en; occOpen = false }) }
                }
            }
            if (register) IconField("users", org, { org = it }, L("প্রতিষ্ঠান", "Organisation"))
            if (register || !viaGoogle) IconField(
                "lock", pin, { pin = it.filter { c -> c.isDigit() } },
                if (register) L("৪ সংখ্যার পিন বানান *", "Make a 4-digit PIN *") else L("পিন *", "PIN *"),
                KeyboardType.NumberPassword, secret = true, max = 4
            )
            if (register) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { agree = !agree }) {
                Checkbox(agree, { agree = it }, colors = CheckboxDefaults.colors(checkedColor = C.brand))
                Text(L("আমি শর্তাবলিতে রাজি। এই অ্যাপের তথ্য ডাক্তারের পরামর্শের বিকল্প নয়।", "I agree to the terms. This app is not a substitute for a doctor's advice."),
                    fontSize = 14.sp, color = C.sub)
            }
            err?.let { Text(it, color = if (it.contains("✓")) C.green else C.red, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }

            // main button
            Box(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(14.dp)).background(if (busy) C.brand.copy(alpha = 0.6f) else C.brand)
                    .clickable(enabled = !busy) {
                        err = null
                        if (register && !agree) { err = L("শর্তাবলিতে টিক দিন", "Please tick the terms box"); return@clickable }
                        busy = true
                        val done: (String?) -> Unit = { e -> busy = false; err = e }
                        if (register) Account.register(name, phone, if (viaGoogle) gEmail else email, occ, org, pin, done) else Account.login(phone, pin, done)
                    }.semantics { role = Role.Button },
                contentAlignment = Alignment.Center
            ) {
                if (busy) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                else Text(if (register) L("রেজিস্টার", "REGISTER") else L("লগইন", "SIGN IN"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            }
            Text(
                if (register) L("আগে রেজিস্টার করেছেন?", "Already registered?") else L("নতুন ইউজার?", "New here?"),
                fontSize = 17.sp, color = Color(0xFF475467), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
            Box(
                Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(14.dp)).background(Color.White)
                    .border(1.5.dp, C.brand, RoundedCornerShape(14.dp)).clickable { register = !register; err = null }
                    .semantics { role = Role.Button },
                contentAlignment = Alignment.Center
            ) {
                Text(if (register) L("লগইন", "SIGN IN") else L("রেজিস্টার", "REGISTER"), color = C.brand, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            }
            Text(
                L("প্রাইভেসি পলিসি ও শর্তাবলি", "Privacy Policy and Terms & Conditions"), color = C.brand, fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().clickable { terms = true }.padding(vertical = 14.dp)
            )
            Text(
                L("প্রথমবার রেজিস্টার/লগইন করতে ইন্টারনেট লাগে। এরপর অফলাইনেও চলবে।", "The first register / sign-in needs internet. After that it works offline."),
                color = C.mute, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)
            )
        }
    }
    if (terms) AlertDialog(
        onDismissRequest = { terms = false },
        title = { Text(L("প্রাইভেসি পলিসি ও শর্তাবলি", "Privacy policy and terms")) },
        text = {
            Text(
                L("• Dawa BD-র তথ্য শুধু জানার জন্য। এটা ডাক্তারের পরামর্শের বিকল্প নয় এবং কোনো রোগ নির্ণয় বা চিকিৎসা করে না।\n• ওষুধ খাওয়া, বন্ধ করা বা ব্র্যান্ড বদলানোর আগে ডাক্তার বা ফার্মাসিস্টের পরামর্শ নিন।\n• দাম ও তথ্য পুরোনো হতে পারে।\n• আপনার নাম, নাম্বার, ইমেইল, পেশা ও প্রতিষ্ঠান শুধু অ্যাকাউন্ট চালানোর জন্য রাখা হয়, কারো কাছে বিক্রি বা শেয়ার করা হয় না।\n• অ্যাকাউন্ট মুছতে চাইলে অ্যাডমিনের সাথে যোগাযোগ করুন।",
                    "• Dawa BD is for reference only. It is not medical advice and does not diagnose or treat any condition.\n• Ask a doctor or pharmacist before taking, stopping or switching any medicine.\n• Prices and details may be out of date.\n• Your name, number, email, occupation and organisation are kept only to run your account and are never sold or shared.\n• To delete your account, contact the admin."),
                lineHeight = 21.sp
            )
        },
        confirmButton = { TextButton({ terms = false }) { Text(L("ঠিক আছে", "OK")) } }
    )
}

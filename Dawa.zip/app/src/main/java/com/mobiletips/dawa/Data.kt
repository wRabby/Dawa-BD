package com.mobiletips.dawa

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import java.io.File

data class Med(
    val id: Long, val brand: String, val form: String, val strength: String,
    val gid: Long, val gname: String, val company: String, val price: String,
)

data class Gen(val id: Long, val name: String, val cls: String, val ind: String, val count: Int, val info: List<Pair<String, String>>)

/** The medicine list lives inside the app (assets/med.db), so search works without internet. */
object Db {
    private var db: SQLiteDatabase? = null
    val ready = mutableStateOf(false)
    var count = ""

    fun open(ctx: Context) {
        if (db != null) return
        val f = ctx.getDatabasePath("med.db")
        val stamp = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        val prefs = ctx.getSharedPreferences("o", Context.MODE_PRIVATE)
        if (!f.exists() || prefs.getLong("dbStamp", 0) != stamp) {
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            ctx.assets.open("med.db").use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            tmp.renameTo(f)
            prefs.edit().putLong("dbStamp", stamp).apply()
        }
        db = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
        count = db?.rawQuery("SELECT v FROM meta WHERE k='count'", null)?.use { if (it.moveToFirst()) it.getString(0) else "" } ?: ""
        ready.value = true
    }

    private fun like(q: String) = q.lowercase().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private const val MED_COLS = "id,brand,form,strength,gid,gname,company,price"

    private fun meds(sql: String, args: Array<String>): List<Med> {
        val d = db ?: return emptyList()
        return d.rawQuery(sql, args).use { c ->
            val out = ArrayList<Med>()
            while (c.moveToNext()) out += Med(
                c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "",
                if (c.isNull(4)) 0 else c.getLong(4), c.getString(5) ?: "", c.getString(6) ?: "", c.getString(7) ?: ""
            )
            out
        }
    }

    /** by = "brand" | "generic" | "company". Names starting with the text come first. */
    fun search(by: String, q: String): List<Med> {
        val t = like(q.trim())
        if (t.isEmpty()) return emptyList()
        val c = when (by) { "generic" -> "g"; "company" -> "c"; else -> "b" }
        return meds(
            "SELECT $MED_COLS FROM med WHERE $c LIKE ? ESCAPE '\\' ORDER BY CASE WHEN $c LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, b, strength LIMIT 150",
            arrayOf("%$t%", "$t%")
        )
    }

    /** Generics whose uses match the text (fever, pain, gastric …). */
    fun byUse(q: String): List<Gen> {
        val t = like(q.trim())
        val d = db ?: return emptyList()
        if (t.isEmpty()) return emptyList()
        return d.rawQuery(
            "SELECT id,name,cls,ind,n FROM gen WHERE (lower(ind) LIKE ? ESCAPE '\\' OR lower(cls) LIKE ? ESCAPE '\\') AND n>0 ORDER BY n DESC LIMIT 150",
            arrayOf("%$t%", "%$t%")
        ).use { c ->
            val out = ArrayList<Gen>()
            while (c.moveToNext()) out += Gen(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getInt(4), emptyList())
            out
        }
    }

    fun med(id: Long): Med? = meds("SELECT $MED_COLS FROM med WHERE id=?", arrayOf("$id")).firstOrNull()

    fun medsOf(ids: List<Long>): List<Med> {
        if (ids.isEmpty()) return emptyList()
        val found = meds("SELECT $MED_COLS FROM med WHERE id IN (${ids.joinToString(",")})", emptyArray()).associateBy { it.id }
        return ids.mapNotNull { found[it] }
    }

    /** Every brand of one generic (the same medicine from other companies). */
    fun brandsOf(gid: Long): List<Med> = meds("SELECT $MED_COLS FROM med WHERE gid=? ORDER BY form, strength, b", arrayOf("$gid"))

    fun gen(id: Long): Gen? {
        val d = db ?: return null
        return d.rawQuery("SELECT id,name,cls,ind,n,info FROM gen WHERE id=?", arrayOf("$id")).use { c ->
            if (!c.moveToFirst()) return null
            val info = ArrayList<Pair<String, String>>()
            try {
                val a = JSONArray(c.getString(5) ?: "[]")
                for (i in 0 until a.length()) { val x = a.getJSONArray(i); info += x.getString(0) to x.getString(1) }
            } catch (_: Exception) {}
            Gen(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getInt(4), info)
        }
    }
}

/** Favourites (⭐) and recently opened medicines, kept on the phone. */
object Saved {
    private lateinit var ctx: Context
    val favs = mutableStateOf<List<Long>>(emptyList())
    val recent = mutableStateOf<List<Long>>(emptyList())

    fun init(c: Context) {
        ctx = c
        val p = c.getSharedPreferences("o", Context.MODE_PRIVATE)
        favs.value = ids(p.getString("favs", ""))
        recent.value = ids(p.getString("recent", ""))
    }

    private fun ids(s: String?) = s.orEmpty().split(",").mapNotNull { it.toLongOrNull() }
    private fun save() = ctx.getSharedPreferences("o", Context.MODE_PRIVATE).edit()
        .putString("favs", favs.value.joinToString(",")).putString("recent", recent.value.joinToString(",")).apply()

    fun toggleFav(id: Long) { favs.value = if (id in favs.value) favs.value - id else listOf(id) + favs.value; save() }
    fun opened(id: Long) { recent.value = (listOf(id) + (recent.value - id)).take(20); save() }
    fun clearRecent() { recent.value = emptyList(); save() }
}

object Lang {
    val code = mutableStateOf("bn")
    fun init(c: Context) { code.value = c.getSharedPreferences("o", Context.MODE_PRIVATE).getString("lang", "bn") ?: "bn" }
    fun set(c: Context, v: String) { code.value = v; c.getSharedPreferences("o", Context.MODE_PRIVATE).edit().putString("lang", v).apply() }
}

/** Bangla or English text by the chosen language. */
fun L(bn: String, en: String): String = if (Lang.code.value == "en") en else bn

/** Bangla titles for the sections of a medicine's information. */
fun sectionTitle(t: String): String {
    if (Lang.code.value == "en") return t
    val s = t.lowercase()
    return when {
        "indication" in s -> "কী কাজে লাগে"
        "therapeutic" in s -> "ওষুধের শ্রেণি"
        "pharmacology" in s -> "কীভাবে কাজ করে"
        "dosage" in s -> "মাত্রা ও সেবনবিধি"
        "administration" in s -> "কীভাবে সেবন করবেন"
        "interaction" in s -> "অন্য ওষুধের সাথে প্রতিক্রিয়া"
        "contraindication" in s -> "কারা খাবেন না"
        "side effect" in s -> "পার্শ্বপ্রতিক্রিয়া"
        "pregnancy" in s -> "গর্ভাবস্থা ও স্তন্যদান"
        "precaution" in s -> "সতর্কতা"
        "pediatric" in s -> "শিশুদের ক্ষেত্রে"
        "overdose" in s -> "অতিরিক্ত সেবন করলে"
        "duration" in s -> "কতদিন খাবেন"
        "reconstitution" in s -> "তৈরির নিয়ম"
        "storage" in s -> "সংরক্ষণ"
        else -> t
    }
}

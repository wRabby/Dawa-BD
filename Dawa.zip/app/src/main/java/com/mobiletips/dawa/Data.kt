package com.mobiletips.dawa

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import java.io.File

data class Med(
    val id: Long, val brand: String, val form: String, val strength: String,
    val gid: Long, val gname: String, val company: String, val price: String,
    val kind: String, val up: Double, val pack: String,
)

data class Gen(val id: Long, val name: String, val cls: String, val ind: String, val count: Int, val info: List<Pair<String, String>>)

/** The medicine list lives inside the app (assets/med.db), so search works without internet. */
object Db {
    private var db: SQLiteDatabase? = null
    val ready = mutableStateOf(false)
    var brands = 0
    var generics = 0

    fun open(ctx: Context) {
        if (db != null) return
        val f = ctx.getDatabasePath("med.db")
        val stamp = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        val prefs = ctx.getSharedPreferences("o", Context.MODE_PRIVATE)
        if (!f.exists() || prefs.getLong("dbStamp", 0) != stamp) {
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            ctx.assets.open("med.db").use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            tmp.renameTo(f)
            prefs.edit().putLong("dbStamp", stamp).apply()
        }
        db = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
        val count = db?.rawQuery("SELECT v FROM meta WHERE k='count'", null)?.use { if (it.moveToFirst()) it.getString(0) else "" } ?: ""
        brands = count.substringBefore('/').toIntOrNull() ?: 0
        generics = count.substringAfter('/').toIntOrNull() ?: 0
        ready.value = true
    }

    private fun like(q: String) = q.lowercase().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private const val COLS = "id,brand,form,strength,gid,gname,company,price,kind,up,pack"

    private fun meds(sql: String, args: Array<String>): List<Med> {
        val d = db ?: return emptyList()
        return try {
            d.rawQuery(sql, args).use { c ->
                val out = ArrayList<Med>()
                while (c.moveToNext()) out += Med(
                    c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "",
                    if (c.isNull(4)) 0 else c.getLong(4), c.getString(5) ?: "", c.getString(6) ?: "", c.getString(7) ?: "",
                    c.getString(8) ?: "", if (c.isNull(9)) 0.0 else c.getDouble(9), c.getString(10) ?: ""
                )
                out
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun gens(sql: String, args: Array<String>): List<Gen> {
        val d = db ?: return emptyList()
        return try {
            d.rawQuery(sql, args).use { c ->
                val out = ArrayList<Gen>()
                while (c.moveToNext()) out += Gen(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getInt(4), emptyList())
                out
            }
        } catch (e: Exception) { emptyList() }
    }

    /** by = "brand" | "generic" | "company" | "herbal". Names starting with the text come first. */
    fun search(by: String, q: String): List<Med> {
        val t = like(q.trim())
        if (by == "herbal") {
            return meds(
                "SELECT $COLS FROM med WHERE kind LIKE '%herb%' AND (b LIKE ? ESCAPE '\\' OR g LIKE ? ESCAPE '\\') ORDER BY CASE WHEN b LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, b LIMIT 200",
                arrayOf("%$t%", "%$t%", "$t%")
            )
        }
        if (t.isEmpty()) return emptyList()
        val c = when (by) { "generic" -> "g"; "company" -> "c"; else -> "b" }
        return meds(
            "SELECT $COLS FROM med WHERE $c LIKE ? ESCAPE '\\' ORDER BY CASE WHEN $c LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, b, strength LIMIT 150",
            arrayOf("%$t%", "$t%")
        )
    }

    /** Generics whose uses match the text (fever, pain, ulcer …). */
    fun byUse(q: String): List<Gen> {
        val t = like(q.trim())
        if (t.isEmpty()) return emptyList()
        return gens(
            "SELECT id,name,cls,ind,n FROM gen WHERE (lower(ind) LIKE ? ESCAPE '\\' OR lower(cls) LIKE ? ESCAPE '\\' OR lower(info) LIKE ? ESCAPE '\\') AND n>0 ORDER BY CASE WHEN lower(ind) LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, n DESC LIMIT 150",
            arrayOf("%$t%", "%$t%", "%$t%", "%$t%")
        )
    }

    /** Drug classes with how many generics each has. */
    fun classes(): List<Pair<String, Int>> {
        val d = db ?: return emptyList()
        return try {
            d.rawQuery("SELECT cls, COUNT(*) FROM gen WHERE cls<>'' AND n>0 GROUP BY cls ORDER BY cls", null).use { c ->
                val out = ArrayList<Pair<String, Int>>()
                while (c.moveToNext()) out += (c.getString(0) ?: "") to c.getInt(1)
                out
            }
        } catch (e: Exception) { emptyList() }
    }

    fun gensOfClass(cls: String): List<Gen> = gens("SELECT id,name,cls,ind,n FROM gen WHERE cls=? AND n>0 ORDER BY name", arrayOf(cls))

    /** Companies with how many brands each has. */
    fun companies(): List<Pair<String, Int>> {
        val d = db ?: return emptyList()
        return try {
            d.rawQuery("SELECT company, COUNT(*) FROM med WHERE company<>'' GROUP BY c ORDER BY company", null).use { c ->
                val out = ArrayList<Pair<String, Int>>()
                while (c.moveToNext()) out += (c.getString(0) ?: "") to c.getInt(1)
                out
            }
        } catch (e: Exception) { emptyList() }
    }

    fun ofCompany(company: String): List<Med> = meds("SELECT $COLS FROM med WHERE c=? ORDER BY b, strength", arrayOf(company.lowercase()))

    fun med(id: Long): Med? = meds("SELECT $COLS FROM med WHERE id=?", arrayOf("$id")).firstOrNull()

    fun medsOf(ids: List<Long>): List<Med> {
        if (ids.isEmpty()) return emptyList()
        val found = meds("SELECT $COLS FROM med WHERE id IN (${ids.joinToString(",")})", emptyArray()).associateBy { it.id }
        return ids.mapNotNull { found[it] }
    }

    /** The same brand in other strengths / forms ("also available"). */
    fun variants(m: Med): List<Med> = meds("SELECT $COLS FROM med WHERE b=? AND c=? ORDER BY form, strength", arrayOf(m.brand.lowercase(), m.company.lowercase()))

    /** Every brand of one generic. */
    fun brandsOf(gid: Long): List<Med> = meds("SELECT $COLS FROM med WHERE gid=? ORDER BY form, strength, b", arrayOf("$gid"))

    /** Same medicine (generic, form, strength) from every company, cheapest first. */
    fun sameMedicine(m: Med): List<Med> = meds(
        "SELECT $COLS FROM med WHERE gid=? AND form=? AND strength=? ORDER BY CASE WHEN up>0 THEN 0 ELSE 1 END, up, b",
        arrayOf("${m.gid}", m.form, m.strength)
    )

    fun gen(id: Long): Gen? {
        val d = db ?: return null
        return try {
            d.rawQuery("SELECT id,name,cls,ind,n,info FROM gen WHERE id=?", arrayOf("$id")).use { c ->
                if (!c.moveToFirst()) return null
                val info = ArrayList<Pair<String, String>>()
                try {
                    val a = JSONArray(c.getString(5) ?: "[]")
                    for (i in 0 until a.length()) { val x = a.getJSONArray(i); info += x.getString(0) to x.getString(1) }
                } catch (_: Exception) {}
                Gen(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getInt(4), info)
            }
        } catch (e: Exception) { null }
    }
}

/** Favourites (♥) and recently opened medicines, kept on the phone. */
object Saved {
    private lateinit var ctx: Context
    val favs = mutableStateOf<List<Long>>(emptyList())
    val recent = mutableStateOf<List<Long>>(emptyList())

    fun init(c: Context) {
        ctx = c
        val p = c.getSharedPreferences("o", Context.MODE_PRIVATE)
        favs.value = ids(p.getString("favs", ""))
        recent.value = ids(p.getString("recent", ""))
    }

    private fun ids(s: String?) = s.orEmpty().split(",").mapNotNull { it.toLongOrNull() }
    private fun save() = ctx.getSharedPreferences("o", Context.MODE_PRIVATE).edit()
        .putString("favs", favs.value.joinToString(",")).putString("recent", recent.value.joinToString(",")).apply()

    fun isFav(id: Long) = id in favs.value
    fun toggleFav(id: Long) { favs.value = if (id in favs.value) favs.value - id else listOf(id) + favs.value; save() }
    fun opened(id: Long) { recent.value = (listOf(id) + (recent.value - id)).take(30); save() }
    fun clearRecent() { recent.value = emptyList(); save() }
}

/** App language: English first; the round ball in the corner switches it. */
object Lang {
    val code = mutableStateOf("en")
    private var ctx: Context? = null
    fun init(c: Context) { ctx = c; code.value = c.getSharedPreferences("o", Context.MODE_PRIVATE).getString("lang", "en") ?: "en" }
    fun toggle() {
        code.value = if (code.value == "en") "bn" else "en"
        ctx?.getSharedPreferences("o", Context.MODE_PRIVATE)?.edit()?.putString("lang", code.value)?.apply()
    }
}

/** Bangla or English text by the chosen language. */
fun L(bn: String, en: String): String = if (Lang.code.value == "bn") bn else en

/** Bangla digits in Bangla mode. */
fun bn(s: String): String = if (Lang.code.value != "bn") s else s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")

fun money(v: Double): String = "৳ " + bn(String.format(java.util.Locale.US, "%.2f", v))

/** Titles for the sections of a medicine's information. */
fun sectionTitle(t: String): String {
    val s = t.lowercase()
    val pair = when {
        "indication" in s -> "কী কাজে লাগে" to "Indications"
        "therapeutic" in s -> "ওষুধের শ্রেণি" to "Therapeutic class"
        "pharmacology" in s -> "কীভাবে কাজ করে" to "Pharmacology"
        "dosage" in s -> "মাত্রা ও সেবনবিধি" to "Dosage & administration"
        "administration" in s -> "কীভাবে সেবন করবেন" to "Administration"
        "interaction" in s -> "অন্য ওষুধের সাথে প্রতিক্রিয়া" to "Interactions"
        "contraindication" in s -> "কারা খাবেন না" to "Contraindications"
        "side effect" in s -> "পার্শ্বপ্রতিক্রিয়া" to "Side effects"
        "pregnancy" in s -> "গর্ভাবস্থা ও স্তন্যদান" to "Pregnancy & lactation"
        "precaution" in s -> "সতর্কতা" to "Precautions & warnings"
        "pediatric" in s -> "শিশুদের ক্ষেত্রে" to "Use in children"
        "overdose" in s -> "অতিরিক্ত সেবন করলে" to "Overdose"
        "duration" in s -> "কতদিন খাবেন" to "Duration of treatment"
        "reconstitution" in s -> "তৈরির নিয়ম" to "Reconstitution"
        "storage" in s -> "সংরক্ষণ" to "Storage"
        else -> t to t
    }
    return L(pair.first, pair.second)
}

fun formName(form: String): String {
    if (Lang.code.value != "bn") return form
    val f = form.lowercase()
    return when {
        "tablet" in f -> "ট্যাবলেট"
        "capsule" in f -> "ক্যাপসুল"
        "syrup" in f -> "সিরাপ"
        "suspension" in f -> "সাসপেনশন"
        "injection" in f -> "ইনজেকশন"
        "drop" in f -> "ড্রপ"
        "cream" in f -> "ক্রিম"
        "ointment" in f -> "মলম"
        "gel" in f -> "জেল"
        else -> form
    }
}

#!/usr/bin/env python3
"""
Turns the medicine CSV files into one small SQLite file that ships inside the app,
so searching works without internet.

  python3 ci/make_db.py <folder with the csv files> <output .db>

Column names are found by their words (the files' exact headers may change a little).
"""
import csv, html, json, os, re, sqlite3, sys

csv.field_size_limit(10**9)
src, out = sys.argv[1], sys.argv[2]


def rows(name):
    path = os.path.join(src, name)
    if not os.path.exists(path):
        return [], []
    with open(path, encoding="utf-8-sig", newline="") as f:
        r = csv.reader(f)
        head = [h.strip() for h in next(r)]
        data = [x for x in r if any(c.strip() for c in x)]
    print(f"{name}: {len(data)} rows; columns: {head}")
    return head, data


def col(head, *want, exact=False):
    low = [h.lower().strip() for h in head]
    for w in want:
        for i, h in enumerate(low):
            if (h == w) if exact else (w in h):
                return i
    return -1


def clean(t):
    t = html.unescape(t or "")
    t = re.sub(r"<\s*br\s*/?>|</p>|</li>", "\n", t, flags=re.I)
    t = re.sub(r"<li[^>]*>", "• ", t, flags=re.I)
    t = re.sub(r"<[^>]+>", "", t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n\s*\n+", "\n", t)
    return t.strip()


# ---------- generics ----------
gh, gd = rows("generic.csv")
g_id = col(gh, "generic id", "generic_id", "id", exact=True)
if g_id < 0: g_id = col(gh, "generic id")
g_name = col(gh, "generic name", "name", exact=True)
if g_name < 0: g_name = col(gh, "generic name")
g_cls = col(gh, "drug class")
g_ind = col(gh, "indication", exact=True)
desc_cols = [i for i, h in enumerate(gh) if "description" in h.lower()]
if g_name < 0:
    sys.exit("generic.csv: could not find the generic name column")

# order of the sections shown in the app
order = ["indication", "therapeutic", "pharmacology", "dosage", "administration", "interaction", "contraindication",
         "side effect", "pregnancy", "precaution", "pediatric", "overdose", "duration", "reconstitution", "storage"]
desc_cols.sort(key=lambda i: next((k for k, w in enumerate(order) if w in gh[i].lower()), 99))

db_tmp = out + ".tmp"
if os.path.exists(db_tmp): os.remove(db_tmp)
db = sqlite3.connect(db_tmp)
db.executescript("""
CREATE TABLE gen(id INTEGER PRIMARY KEY, name TEXT, g TEXT, cls TEXT, ind TEXT, info TEXT, n INTEGER DEFAULT 0);
CREATE TABLE med(id INTEGER PRIMARY KEY, brand TEXT, b TEXT, form TEXT, strength TEXT, gid INTEGER, gname TEXT, g TEXT,
                 company TEXT, c TEXT, price TEXT, kind TEXT, up REAL DEFAULT 0, pack TEXT);
CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT);
""")
by_id, by_name = {}, {}
for n, r in enumerate(gd, 1):
    get = lambda i: r[i].strip() if 0 <= i < len(r) else ""
    name = get(g_name)
    if not name: continue
    try: gid = int(float(get(g_id))) if g_id >= 0 else n
    except ValueError: gid = n
    info = []
    for i in desc_cols:
        t = clean(get(i))
        if t: info.append([gh[i].replace(" description", "").replace("_", " ").strip().title(), t])
    by_id[gid] = gid
    by_name.setdefault(name.lower(), gid)
    db.execute("INSERT OR REPLACE INTO gen(id,name,g,cls,ind,info) VALUES(?,?,?,?,?,?)",
               (gid, name, name.lower(), get(g_cls), get(g_ind), json.dumps(info, ensure_ascii=False)))

# ---------- brands ----------
mh, md = rows("medicine.csv")
m_brand = col(mh, "brand name")
m_form = col(mh, "dosage form")
m_str = col(mh, "strength")
m_gen = col(mh, "generic", "generic name", exact=True)
if m_gen < 0: m_gen = col(mh, "generic name")
m_gid = col(mh, "generic id")
m_comp = col(mh, "manufacturer", "company")
m_kind = col(mh, "type", exact=True)
price_cols = [i for i, h in enumerate(mh) if "package" in h.lower() or "price" in h.lower()]
if m_brand < 0:
    sys.exit("medicine.csv: could not find the brand name column")

names = {v: k for k, v in by_name.items()}
for n, r in enumerate(md, 1):
    get = lambda i: r[i].strip() if 0 <= i < len(r) else ""
    brand = get(m_brand)
    if not brand: continue
    gname = get(m_gen)
    gid = None
    if m_gid >= 0:
        try: gid = int(float(get(m_gid)))
        except ValueError: gid = None
    if gid is None and gname: gid = by_name.get(gname.lower())
    if not gname and gid is not None:
        row = db.execute("SELECT name FROM gen WHERE id=?", (gid,)).fetchone()
        gname = row[0] if row else ""
    parts = [clean(get(i)) for i in price_cols if clean(get(i))]
    price = " · ".join(parts)
    # unit price = the first amount in the text (৳ 1.20); pack text = the rest
    up = 0.0
    mm = re.search(r"([0-9][0-9,]*\.?[0-9]*)", price.split("pack")[0] if "Unit" in price else price)
    if mm:
        try: up = float(mm.group(1).replace(",", ""))
        except ValueError: up = 0.0
    pack = " · ".join(p for p in parts if "pack" in p.lower() or "x" in p.lower())
    comp = get(m_comp)
    db.execute("INSERT INTO med(brand,b,form,strength,gid,gname,g,company,c,price,kind,up,pack) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
               (brand, brand.lower(), get(m_form), get(m_str), gid, gname, gname.lower(), comp, comp.lower(), price, get(m_kind).lower(), up, pack))

db.execute("UPDATE gen SET n=(SELECT COUNT(*) FROM med WHERE med.gid=gen.id)")
db.executescript("""
CREATE INDEX med_b ON med(b);
CREATE INDEX med_g ON med(g);
CREATE INDEX med_c ON med(c);
CREATE INDEX med_gid ON med(gid);
CREATE INDEX gen_g ON gen(g);
CREATE INDEX med_kind ON med(kind);
CREATE INDEX gen_cls ON gen(cls);
""")
mc = db.execute("SELECT COUNT(*) FROM med").fetchone()[0]
gc = db.execute("SELECT COUNT(*) FROM gen").fetchone()[0]
db.execute("INSERT INTO meta VALUES('count', ?)", (f"{mc}/{gc}",))
db.commit()
db.execute("VACUUM")
db.close()
os.replace(db_tmp, out)
print(f"Done: {mc} brands, {gc} generics -> {out} ({os.path.getsize(out)//1024} KB)")
if mc < 100:
    sys.exit("Too few medicines - the data did not load correctly")

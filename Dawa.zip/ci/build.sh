#!/usr/bin/env bash
# Build steps live here (inside the zip), so build.yml never needs editing again.
set -e
# 1) Medicine data -> app/src/main/assets/med.db (searching works offline)
mkdir -p data app/src/main/assets
HF=https://huggingface.co/datasets/ArnobBot/Medicine-Dataset-of-Bangladesh/resolve/main
for f in medicine.csv generic.csv; do
  [ -s "data/$f" ] || curl -fsSL --retry 3 -o "data/$f" "$HF/$f"
done
python3 ci/make_db.py data app/src/main/assets/med.db

# 2) The APK
set +e
gradle assembleDebug --no-daemon --stacktrace > debug.log 2>&1
dcode=$?
set -e
cat debug.log
if [ $dcode -ne 0 ]; then
  reason=$(grep -E "^e: |What went wrong" -A3 debug.log | head -20 | tr '\n' ' ' | cut -c1-900)
  echo "::error::APK build failed: ${reason:-see the Build step log}"
  exit 1
fi
cp app/build/outputs/apk/debug/app-debug.apk Dawa.apk

#!/usr/bin/env bash
# Build steps live here (inside the zip), so build.yml never needs editing again.
set -e
# 1) Medicine data -> app/src/main/assets/med.db (searching works offline)
mkdir -p data app/src/main/assets
HF=https://huggingface.co/datasets/ArnobBot/Medicine-Dataset-of-Bangladesh/resolve/main
for f in medicine.csv generic.csv; do
  [ -s "data/$f" ] || curl -fsSL --retry 3 -o "data/$f" "$HF/$f"
done
python3 ci/make_db.py data app/src/main/assets/med.db

# Firebase settings (google-services.json uploaded to the repo)
if [ -f google-services.json ]; then cp google-services.json app/google-services.json; fi

# 2) The APK
set +e
gradle assembleDebug --no-daemon --stacktrace > debug.log 2>&1
dcode=$?
set -e
cat debug.log
if [ $dcode -ne 0 ]; then
  reason=$(grep -E "^e: |What went wrong" -A3 debug.log | head -20 | tr '\n' ' ' | cut -c1-900)
  echo "::error::APK build failed: ${reason:-see the Build step log}"
  exit 1
fi
cp app/build/outputs/apk/debug/app-debug.apk Dawa.apk

# 3) The Play Store bundle (.aab), signed with app/upload.jks (password: secret UPLOAD_PASSWORD, else ci/upload.pw)
opens() { keytool -list -keystore app/upload.jks -storepass "$1" >/dev/null 2>&1; }
PW=$(printf '%s' "$UPLOAD_PASSWORD" | tr -d '[:space:]')
if [ -z "$PW" ] || ! opens "$PW"; then PW=$(tr -d '[:space:]' < ci/upload.pw 2>/dev/null); fi
if [ -z "$PW" ] || ! opens "$PW"; then echo "::error::No working password for app/upload.jks - .aab skipped."; exit 0; fi
export UPLOAD_PASSWORD="$PW"
set +e
gradle bundleRelease --no-daemon --stacktrace > bundle.log 2>&1
code=$?
set -e
cat bundle.log
if [ $code -ne 0 ]; then
  reason=$(grep -A6 "What went wrong" bundle.log | tr '\n' ' ' | cut -c1-600)
  echo "::error::AAB build failed: ${reason:-see the Build step log}"
  exit 0
fi
cp app/build/outputs/bundle/release/app-release.aab Dawa.aab
echo "Play Store bundle ready: Dawa.aab"
